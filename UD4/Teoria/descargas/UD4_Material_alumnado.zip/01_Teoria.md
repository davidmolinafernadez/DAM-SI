# Unidad 4. Instalación de sistemas y virtualización

Sistemas Informáticos · 1.º de DAM · Cuaderno de teoría

## Cómo trabajar esta unidad

Vas a construir un laboratorio que permita instalar, comprobar, estropear de forma controlada y recuperar sistemas operativos. El objetivo profesional es entregar un equipo que otra persona pueda utilizar y mantener. Llegar al escritorio es un paso intermedio: faltan actualizaciones, comprobación de dispositivos, conectividad, protección de datos y documentación.

La unidad se organiza en doce bloques. Cada bloque enlaza actividades escritas y prácticas en páginas diferentes. Las actividades se resuelven con razonamiento y las prácticas ejecutando un procedimiento verificable. Antes de ejecutar una instrucción, di qué esperas observar; después compara el resultado real con esa predicción. Un resultado inesperado es una oportunidad para diagnosticar, siempre que conserves un estado recuperable.

Laboratorio de referencia: anfitrión x86-64, VirtualBox de la rama estable aprobada por el centro, Ubuntu Desktop 24.04 LTS y Windows 11 de la edición autorizada. Ubuntu 24.04 se mantiene como referencia para aprovechar los materiales previos; no se presenta como la LTS más reciente. Registra las versiones exactas utilizadas. Los nombres y el orden de algunas pantallas cambian entre versiones.

## B1. Instalar es tomar decisiones
### 1.1. Un encargo real

Un estudio de desarrollo web necesita un equipo Windows para una herramienta de diseño y un entorno Linux para probar aplicaciones. Las personas desarrolladoras deben poder ensayar cambios sin perder su entorno de trabajo. Antes de descargar nada, hay que decidir si conviene utilizar dos equipos, arranque dual, máquinas virtuales o contenedores.

La decisión depende del uso. Un programa que necesita una GPU concreta puede requerir instalación física. Un ejercicio que compara sistemas completos encaja en máquinas virtuales. Una aplicación con dependencias repetibles puede distribuirse en un contenedor. Ninguna opción elimina la necesidad de actualizar, controlar accesos y respaldar datos.

### 1.2. Tipos de instalación

Una instalación limpia crea un sistema nuevo sobre un destino elegido. Puede borrar particiones o reutilizar algunas: «limpia» describe el sistema resultante, pero no garantiza que los datos estén protegidos. Una actualización conserva parte del entorno y cambia componentes del sistema; puede fallar por incompatibilidad o falta de espacio. Una reparación intenta restablecer el arranque o los archivos dañados. Un despliegue desde imagen reproduce una preparación previa y exige atender a las identidades, el hardware y las licencias del destino.

En el arranque dual dos sistemas comparten el equipo y se elige uno al encender. No se ejecutan simultáneamente. Una VM ejecuta un sistema invitado mientras el anfitrión continúa funcionando. El arranque dual reparte espacio de disco; la virtualización también reparte RAM y CPU durante la ejecución.

### 1.3. Plan de instalación

Un plan útil identifica destinatario, aplicaciones, arquitectura, requisitos, fuente de instalación, licencias, esquema de almacenamiento, configuración de red, cuentas, pruebas de aceptación y recuperación. Tiene que ser lo bastante concreto para que otra persona lo ejecute sin adivinar decisiones.

Ejemplo: «Ubuntu para prácticas» es insuficiente. «VM Ubuntu Desktop 24.04 LTS amd64; 2 vCPU; 4 GiB de RAM; disco virtual dinámico de 50 GiB; NAT; usuario alumno; zona Europe/Madrid; verificar inicio sin ISO y actualización de paquetes» permite comprobar el resultado. Estas cifras son una propuesta de aula, no requisitos oficiales universales.

### 1.4. Mínimo, recomendado y disponible

El mínimo permite cumplir una condición de instalación; el recomendado busca una experiencia razonable. Lo disponible es lo que queda después de atender al anfitrión y a las demás cargas. Un ordenador con 8 GiB no dispone de 8 GiB libres para invitados. Si el anfitrión pagina continuamente, una VM con muchos recursos asignados puede funcionar peor.

Reserva orientativa para un anfitrión de 16 GiB: 6 GiB para el sistema y aplicaciones, 4 GiB para Ubuntu, 4 GiB para Windows y 2 GiB de margen. Es una hipótesis que debe medirse. En equipos de 8 GiB se trabajará con una VM cada vez y se ajustará el escritorio o se utilizará un equipo del aula. No se rebajan los requisitos de Windows para forzar el ejercicio.

### 1.5. Convertir una necesidad en una prueba

Un requisito expresa una necesidad; una prueba muestra si se satisface. «Necesito Linux para desarrollar» todavía no concreta arquitectura, memoria ni aplicaciones. «Necesito ejecutar Python y servir una página local a un navegador del anfitrión» permite decidir sistema, red y comprobación. La prueba no debe depender de una opinión como «va rápido» sin describir la carga y las condiciones.

Un plan tiene además un orden. Descargar antes de comprobar arquitectura puede obligar a repetir una descarga de varios gigabytes. Instalar antes de identificar los discos puede afectar datos que no eran el destino. Actualizar sin un estado de retorno dificulta separar un fallo previo de uno introducido por el cambio.

| Decisión | Qué información necesita | Cómo se comprobará |
| --- | --- | --- |
| Sistema y arquitectura | Aplicación, CPU y soporte | Versión instalada y aplicación ejecutada |
| Memoria del invitado | Carga y reserva del anfitrión | Consumo observado sin presión excesiva |
| Destino de instalación | Discos, particiones y datos existentes | Resumen antes de escribir y mapa posterior |
| Red | Quién inicia la conexión | Petición al servicio desde el origen previsto |
| Recuperación | Tipo de fallo que debe cubrirse | Retorno o restauración con archivo testigo |

### 1.6. Tres instalaciones con efectos diferentes

Una instalación nueva sobre un disco vacío no tiene los mismos riesgos que reinstalar un equipo de trabajo. En el segundo caso importan datos, licencias, configuración y recuperación. Actualizar conservando programas tampoco elimina riesgos: puede haber incompatibilidades, cambios de controladores y espacio temporal insuficiente. Por eso el inventario y la copia previa se deciden antes de abrir el asistente.

En el aula se elige una VM con disco vacío para estudiar el proceso con un destino claro. Esta elección no autoriza a trasladar «Borrar disco» al ordenador familiar. Lo que se aprende es a identificar el destino y razonar el efecto de cada pantalla, de forma que luego pueda aplicarse el mismo criterio a otro entorno.

## B2. Virtualización: qué se crea realmente
### 2.1. Anfitrión, invitado e hipervisor

El anfitrión es el equipo que aporta los recursos. El invitado es el sistema que se ejecuta dentro de la máquina virtual. El hipervisor organiza la ejecución y presenta dispositivos virtuales. Una VM tiene configuración de CPU, memoria, firmware, almacenamiento y red; un disco virtual es solamente una parte de ella.

Esquema del laboratorio: hardware físico → sistema anfitrión → VirtualBox → hardware virtual → sistema invitado → aplicaciones. El invitado ve, por ejemplo, una tarjeta de red virtual, aunque el ordenador físico se conecte mediante Wi-Fi. Por eso el instalador puede mostrar una conexión «por cable» dentro de la VM.

En un hipervisor de tipo 1, la capa de virtualización actúa directamente sobre el hardware; en uno de tipo 2, la aplicación funciona sobre un sistema anfitrión. Esta clasificación es introductoria: tecnologías como Hyper-V tienen una arquitectura más compleja que la apariencia de su consola. VirtualBox es la herramienta de escritorio utilizada en esta unidad.

### 2.2. Virtualizar, emular y contenerizar

Virtualizar permite ejecutar invitados aprovechando la arquitectura y las capacidades de la CPU. Emular reproduce el comportamiento de otra máquina y puede permitir una arquitectura distinta, con un coste de traducción. Descargar una ISO ARM64 para una VM x86-64 no se soluciona aumentando la RAM.

Un contenedor Linux comparte el kernel del sistema Linux que lo ejecuta y aísla procesos, archivos y recursos. Puede contener herramientas de Ubuntu sin arrancar su propio kernel como haría una VM Ubuntu. En Windows, una herramienta de contenedores Linux suele apoyarse en una capa Linux, como WSL 2 o una VM. Por eso «los contenedores nunca utilizan máquinas virtuales» es una conclusión incorrecta.

### 2.3. CPU y memoria virtuales

Una vCPU es una unidad de ejecución presentada al invitado. Asignar cuatro no reserva necesariamente cuatro núcleos físicos exclusivos. Si varios invitados compiten, el hipervisor reparte tiempo. Empezaremos con dos vCPU para los escritorios del laboratorio y mediremos antes de aumentar.

La memoria asignada necesita respaldo en el anfitrión. No se debe confundir la RAM con el almacenamiento del archivo VDI. Un invitado puede tener 4 GiB de RAM y un disco virtual de 50 GiB. El primero condiciona la ejecución; el segundo, los datos que puede almacenar.

VT-x y AMD-V son extensiones de virtualización de CPU. El firmware puede permitir activarlas o desactivarlas. La disponibilidad también depende de la configuración del anfitrión. Si aparece un error de acceso a virtualización, registra el texto exacto y comprueba el estado: no desactives características de seguridad del equipo por ensayo y error.

### 2.4. Aislamiento y límites

Una VM ayuda a contener cambios, pero puede acceder a recursos reales a través de red, carpetas compartidas, USB o portapapeles. Una carpeta compartida con escritura permite modificar archivos del anfitrión. Para esta unidad se comparten solamente carpetas específicas, con archivos de prueba y permisos mínimos.

Un sistema invitado desactualizado no se convierte en seguro por estar dentro de una ventana. Tampoco deben probarse programas maliciosos para demostrar aislamiento. Las averías de esta unidad son reversibles y se provocan con archivos y configuraciones del laboratorio.

### 2.5. Qué está mirando realmente cada sistema

Imagina un equipo físico con 8 procesadores lógicos. El administrador del anfitrión muestra esos recursos. Si la VM tiene 2 vCPU, sus herramientas normalmente mostrarán las dos unidades que el hipervisor le presenta, no un inventario completo de la placa física. Ambas observaciones pueden ser correctas: describen niveles distintos.

Lo mismo ocurre con los dispositivos. La VM puede ver una controladora SATA virtual sobre un archivo alojado en un SSD NVMe del anfitrión. El nombre del controlador invitado no cambia el hardware físico donde finalmente se guardan los datos. Confundir ambos niveles lleva a diagnósticos erróneos, como buscar en Ubuntu el modelo exacto de la tarjeta Wi-Fi real.

### 2.6. Por qué la asignación debe medirse

Asignar más RAM puede ayudar si faltaba memoria al invitado, pero perjudicar si el anfitrión empieza a intercambiar páginas continuamente. Asignar más vCPU puede aumentar competencia por ejecución. El procedimiento razonable es medir una carga definida, cambiar un parámetro, repetir y comparar. Si se cambian cuatro recursos a la vez, cuesta explicar qué causó la mejora.

## B3. Medios de instalación e integridad
### 4.1. ISO, disco virtual e imagen de despliegue

Una ISO representa el contenido de un medio óptico y suele incluir el instalador arrancable. Se conecta a la unidad óptica virtual. Un VDI almacena los sectores de un disco virtual donde se instalará el sistema. Un OVA es un paquete de intercambio que agrupa una descripción de máquina y sus discos. Cambiar la extensión de una ISO a VDI no transforma un instalador en un disco instalado.

Un USB arrancable requiere escribir una estructura de arranque adecuada. Copiar una ISO como archivo a un pendrive ordinario no garantiza que arranque. En el laboratorio principal no hace falta preparar un USB: la ISO se conecta directamente a la VM.

### 4.2. Elegir una descarga

Selecciona producto, edición, versión, arquitectura e idioma. Guarda la URL oficial, el nombre completo, la fecha de descarga y el tamaño. Conserva el comprobante de licencia o la autorización del centro cuando corresponda. Las ISO de Windows y los derechos de uso son asuntos distintos: disponer del instalador no concede una licencia.

No se usarán ISO modificadas para saltar requisitos. En Windows se utilizará el medio y la edición autorizados por el centro, o una evaluación oficial si sus condiciones cubren el laboratorio. La opción «No tengo clave» no convierte automáticamente Windows Pro en una edición de evaluación.

### 4.3. Qué demuestra SHA-256

Un hash es una huella calculada a partir de los bytes del archivo. Si cambia el archivo, la huella normalmente cambia. Para comprobar una descarga, calcula SHA-256 y compara los 64 caracteres hexadecimales con los publicados para ese archivo exacto. Una coincidencia permite comprobar integridad frente a esa referencia; la confianza depende también de la procedencia de la referencia.

En PowerShell, desde la carpeta donde está la ISO, sustituye el nombre por el archivo real:

```powershell
Get-FileHash -LiteralPath '.\ubuntu-24.04.x-desktop-amd64.iso' -Algorithm SHA256
```

En Linux:

```bash
sha256sum ubuntu-24.04.x-desktop-amd64.iso
```

No copies literalmente la «x»: representa la revisión descargada. El hash correcto cambia con cada imagen. Comparar solamente el principio o el final no constituye una verificación completa. Si no coincide, no instales: comprueba nombre, revisión y referencia; después vuelve a descargar si procede.

### 4.4. Integridad y autenticidad

Si alguien sustituyera tanto una imagen como un fichero de hashes, podrían coincidir entre sí. Una firma digital permite comprobar quién firmó el fichero de hashes, siempre que se verifique también la identidad de la clave. Ubuntu publica SHA256SUMS y una firma asociada. La ampliación de P0 propone seguir el procedimiento oficial de verificación de firma, sin importar claves de procedencia desconocida. Referencia F1.

### 4.5. Una descarga se identifica por algo más que su nombre comercial

«Ubuntu 24.04» identifica una familia de versión, pero pueden existir revisiones, arquitecturas y ediciones distintas. La referencia que acompaña a una ISO se debe contrastar con el nombre exacto. El tamaño orienta sobre una descarga incompleta, pero no sustituye una huella: dos archivos del mismo tamaño pueden tener contenido diferente.

Una firma comprueba la relación entre un documento y una clave; la identidad de esa clave también necesita una fuente fiable. No basta con que el programa muestre «firma correcta» si se importó una clave que nadie ha autenticado. En el aula se separa la práctica básica de integridad de la ampliación de autenticidad para que el alumnado pueda decir con precisión qué ha demostrado.

## B4. Firmware, arranque y particiones
### 4.1. Del botón al escritorio

En un arranque normal, el firmware inicializa dispositivos y selecciona un medio. Después se ejecuta un cargador, se carga el kernel y se inicia el sistema de servicios y la sesión. Un error temprano puede impedir que aparezca siquiera el logotipo del sistema. Un error posterior puede permitir arrancar, pero impedir la sesión gráfica.

En una VM la selección de medios es virtual: disco duro, unidad óptica o red. Si el disco está vacío y no hay ISO arrancable, no existe un sistema que cargar. Si se deja la ISO conectada, puede reaparecer el instalador aunque la instalación en el disco sea correcta.

### 4.2. BIOS, UEFI, Secure Boot y TPM

BIOS heredada y UEFI son modelos de firmware. UEFI puede gestionar entradas de arranque que apuntan a cargadores en una partición EFI. Secure Boot comprueba firmas de componentes de arranque según las claves configuradas. TPM aporta funciones criptográficas, como protección de claves y medición. UEFI, Secure Boot y TPM son conceptos diferentes, aunque aparezcan juntos en los requisitos de un sistema.

Para Windows 11 hay que comprobar CPU compatible, al menos dos procesadores virtuales, 4 GB de memoria, 64 GB de almacenamiento, firmware UEFI con capacidad de arranque seguro y TPM 2.0. La compatibilidad del anfitrión también importa. Son condiciones mínimas; la práctica propone más margen de disco. Consulta F2 y configura las opciones que exija la edición y el hipervisor empleados.

No se modifica el firmware de una VM instalada como si fuera una preferencia visual. Un sistema preparado para un modo puede dejar de arrancar si se cambia a otro. Antes de experimentar, crea un clon completo de prueba y documenta la configuración original.

### 4.3. Disco, tabla, partición y sistema de archivos

El disco es el dispositivo de almacenamiento. La tabla describe divisiones. Una partición es una región del disco. El sistema de archivos organiza archivos y directorios dentro de un volumen. Formatear una partición no es lo mismo que crear la tabla de particiones de todo el disco.

Ejemplo didáctico de disco Linux UEFI de 50 GiB: partición EFI de 1 GiB en FAT32, raíz de 30 GiB en ext4 y /home con el resto. Los tamaños son decisiones del laboratorio, no un estándar obligatorio. Los metadatos, alineación y unidades pueden producir pequeñas diferencias. El instalador automático puede elegir otro reparto válido.

### 4.4. MBR y GPT sin reglas falsas

MBR utiliza entradas para hasta cuatro particiones primarias; una puede actuar como extendida que contiene unidades lógicas. Su límite de direccionamiento habitual, con sectores lógicos de 512 bytes, ronda los 2 TiB. No debe expresarse sin indicar el contexto del tamaño de sector.

GPT usa identificadores y mantiene información redundante de la tabla. El número de particiones depende de la implementación y la tabla disponible; no es «infinito». Windows permite habitualmente hasta 128 en una unidad GPT. GPT no exige universalmente UEFI: existen combinaciones con BIOS y cargadores compatibles. Para la instalación moderna de Windows en modo UEFI se utiliza GPT. Referencia F3.

### 4.5. Qué hace cada partición

La ESP contiene archivos de arranque UEFI y usa FAT32. La raíz Linux, montada en /, contiene el árbol principal del sistema. /home contiene los directorios personales cuando se separa en otra partición. La swap amplía opciones de memoria y puede ser archivo o partición; no reemplaza una cantidad adecuada de RAM. Windows suele crear ESP, MSR, partición del sistema y recuperación; no borres las pequeñas porque no tengan letra.

Una partición de datos en el mismo disco facilita separar contenidos, pero no protege frente a la pérdida del disco. Un /home separado tampoco sustituye una copia. Un reinstalador puede formatearlo si se selecciona la opción equivocada.

### 4.6. Localizar el fallo en la cadena de arranque

Si el firmware no encuentra medio, todavía no tiene sentido diagnosticar un servicio del escritorio. Si aparece un cargador pero no encuentra raíz, ya se han superado etapas anteriores. Si el kernel y los servicios arrancan y falla la sesión gráfica, la investigación se sitúa en otro nivel. El síntoma se interpreta por el punto alcanzado, no por una solución repetida para todos los errores.

| Etapa observada | Pregunta inicial | Comprobación de lectura |
| --- | --- | --- |
| No aparece medio arrancable | ¿Hay disco instalado o ISO válida? | Configuración de almacenamiento y orden |
| Se abre el instalador otra vez | ¿Sigue conectada la ISO? | Unidad óptica y destino de arranque |
| Cargador con error | ¿El modo de firmware y destino son coherentes? | Entradas y disco esperado |
| Escritorio sin persistencia | ¿Es una sesión Live? | Raíz montada y prueba tras reinicio sin ISO |

### 4.7. Primaria, extendida y lógica en su contexto

La partición extendida es un mecanismo del esquema MBR para alojar unidades lógicas dentro de una de sus entradas principales. No es una partición que se formatea directamente para guardar documentos. GPT organiza sus entradas de otra manera; no hay que forzar la terminología primaria/extendida para explicar un disco GPT moderno.

Tampoco debe memorizarse un máximo de unidades lógicas como si fuera idéntico en todos los sistemas. El soporte depende de herramientas, controladores y convenciones. En el laboratorio importa reconocer la estructura que realmente muestra el disco y justificar por qué se elige GPT para el itinerario UEFI.

## B5. Sistemas de archivos y montaje
### 5.1. Qué organiza un sistema de archivos

Además de los datos de los archivos, hay metadatos: nombres, tamaños, permisos, propietarios, fechas y referencias a bloques. Una carpeta ayuda a localizar entradas; no es una caja física de sectores contiguos. Borrar un nombre no equivale siempre a sobrescribir inmediatamente todos los datos asociados.

El journaling registra operaciones para mejorar la recuperación de coherencia tras interrupciones. No recupera automáticamente un documento borrado ni convierte la unidad en una copia de seguridad. El cifrado protege datos frente a determinados accesos sin la clave; también exige planificar cómo recuperar la clave.

### 5.2. Elegir según el uso

NTFS es habitual para el sistema Windows y permite permisos y archivos grandes. ext4 es una elección habitual para Linux. FAT32 tiene amplia compatibilidad y limita el tamaño de un archivo a 4 GiB menos 1 byte. exFAT suele servir para intercambio de archivos grandes entre sistemas, pero no ofrece el mismo modelo de permisos que NTFS o ext4. FAT32 conserva un papel importante en la partición EFI.

No existe un «mejor sistema de archivos» para todos los destinos. Para una ISO de 6 GiB en una memoria de intercambio, FAT32 sería una elección problemática. Para la raíz del Ubuntu de esta unidad elegiremos ext4. Para el sistema Windows dejaremos que el instalador utilice el esquema correspondiente. La actividad se centra en justificar decisiones, no en memorizar máximos teóricos dependientes de implementación.

### 5.3. Letras y puntos de montaje

Windows suele mostrar volúmenes mediante letras como C: o D:. Linux integra los sistemas de archivos en un árbol mediante puntos de montaje. /home es un directorio que puede pertenecer a la raíz o ser el punto donde se monta otro volumen.

No confíes en que /dev/sdb será siempre el disco secundario: el orden puede cambiar y puede haber nombres NVMe o distintos controladores. Compara tamaño, tipo, identificadores y montajes. Para referencias persistentes se pueden usar UUID. Dos discos clonados pueden compartir UUID, una razón adicional para planificar cómo se conectan.

Comprobaciones de lectura en Ubuntu:

```bash
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS
findmnt /
df -hT
```

lsblk describe dispositivos y su jerarquía; findmnt muestra qué se ha montado; df informa del uso de sistemas montados. Un disco sin montar puede aparecer en lsblk y no en df. No es una contradicción.

### 5.4. Capacidad aparente y capacidad física

GB decimal y GiB binario no son iguales. Un fabricante y una herramienta pueden representar la misma capacidad con cifras diferentes. Además, un disco virtual dinámico presenta al invitado su capacidad máxima, mientras el archivo del anfitrión crece según se escriben datos y metadatos. Borrar archivos dentro del invitado no garantiza que el archivo VDI se reduzca inmediatamente.

### 5.5. Leer una jerarquía de dispositivos

En una salida de lsblk, el nivel superior puede representar un disco y los inferiores sus particiones. El tipo `disk` no significa que ya haya un sistema de archivos montado. Si aparece `part`, se trata de una partición; su columna de formato puede seguir vacía antes de crear un sistema de archivos. La columna de montajes indica dónde se integra lo que está disponible para acceder a archivos.

Un directorio y un volumen no son equivalentes. Si creas `/mnt/datos` y no montas nada ahí, escribir dentro puede estar utilizando el sistema de archivos raíz. Por eso, antes de celebrar que el disco de datos funciona, hay que consultar findmnt y comprobar que la ruta corresponde al volumen previsto.

### 5.6. Desmontar también es una operación técnica

El sistema puede mantener escrituras pendientes. Desmontar de forma ordenada permite cerrar el acceso y completar operaciones antes de retirar el dispositivo. Si una herramienta indica que el volumen está ocupado, comprueba archivos y terminales que lo estén usando. No fuerces la retirada como respuesta inicial: el mensaje describe una condición que debe investigarse.

## B6. Crear una máquina que se pueda mantener
### 6.1. Archivos y ubicación

La carpeta de una VM puede incluir configuración .vbox, discos, registros y datos de instantáneas. Copiar solamente el primer VDI puede dejar fuera cambios recientes almacenados en discos diferenciales. Utiliza las operaciones del hipervisor para clonar, mover o exportar.

Guarda el laboratorio en almacenamiento local aprobado, con suficiente espacio. Evita ejecutar una VM mientras su carpeta se sincroniza activamente o se copia parcialmente. El medio de respaldo debe ser independiente del disco de trabajo cuando se pretenda proteger frente a su avería.

### 6.2. Disco fijo o dinámico

Un disco fijo reserva aproximadamente su capacidad desde el principio. Uno dinámico empieza ocupando menos y crece hasta el límite configurado, con variaciones de formato y metadatos. En ambos casos, el invitado ve una capacidad lógica. Si se agota el espacio físico del anfitrión, la VM puede sufrir errores aunque su partición tenga espacio libre.

El disco dinámico facilita el aula, pero requiere vigilancia. Para dos máquinas de escritorio, clones, exportaciones y varias instantáneas, no basta con sumar el espacio actualmente usado por Windows y Ubuntu. La guía docente incluye un cálculo de presupuesto y margen.

### 6.3. Estados de una VM

Apagada significa que el sistema ha finalizado su sesión y ya no se ejecuta. Pausada detiene temporalmente la ejecución. Guardar estado conserva la memoria y la ejecución para reanudar. No equivale a completar un apagado ordenado. Forzar apagado se parece a cortar la corriente y puede perder escrituras pendientes.

Para las prácticas de almacenamiento, clonación y cambios de firmware, apagaremos el invitado desde su propio sistema y comprobaremos el estado apagado en VirtualBox. Así se reducen ambigüedades y se facilita repetir los pasos.

### 6.4. Guest Additions y Extension Pack

Las Guest Additions se instalan dentro del invitado e incorporan controladores y servicios de integración, como ajuste de pantalla y determinadas funciones de intercambio. El Extension Pack se añade al hipervisor del anfitrión y habilita funciones adicionales según la versión. Son productos diferentes. Las prácticas básicas no requieren instalar el Extension Pack. Referencias F4 y F5.

Si una función de integración no funciona, comprueba versión, servicio, permisos y reinicio. No reinstales el sistema completo por un fallo de portapapeles. En Ubuntu la construcción de módulos puede requerir herramientas, cabeceras del kernel y, con Secure Boot, gestión de firma de módulos. La práctica ofrece una ruta alternativa si el centro distribuye los complementos como paquetes.

### 6.5. Menú de VirtualBox y menú del invitado

En el administrador, **Configuración → Red** cambia el dispositivo virtual y su conexión. Dentro de Ubuntu, **Configuración → Red** modifica el perfil IP que utiliza el sistema invitado. Los dos controles influyen en la comunicación, pero en niveles diferentes. Añadir una tarjeta virtual no configura automáticamente una dirección estática en Ubuntu.

La unidad óptica también tiene dos vistas. Desde el administrador conectas un archivo ISO al dispositivo; dentro del invitado aparece como un CD que se puede montar y leer. No se debe buscar el archivo `.vdi` dentro del CD ni ejecutar el instalador de VirtualBox para instalar Guest Additions: el primero pertenece al anfitrión y los complementos al invitado.

## B7. Instalar Ubuntu y comprobar el resultado
### 7.1. Probar no es instalar

El modo Live permite ejecutar un entorno desde la ISO. Es útil para comprobar dispositivos o inspeccionar un disco que no arranca. Los cambios de una sesión Live ordinaria pueden perderse al reiniciar. Abrir el escritorio Live no demuestra que Ubuntu esté instalado en el disco virtual.

La prueba decisiva será apagar, retirar la ISO y arrancar desde el disco. Si el sistema funciona, comprobarás además que el usuario y un archivo creado antes del reinicio siguen presentes.

### 7.2. Decisiones del instalador

Antes de confirmar, identifica idioma, teclado, zona horaria, red, modalidad de instalación y disco de destino. La práctica P2 utiliza instalación interactiva en un único VDI vacío. La instalación automática o desatendida se reserva para una ampliación, porque el aprendizaje inicial requiere ver las decisiones.

En «Borrar disco», el disco debe ser el VDI de la VM de prácticas. Esta instrucción no se traslada a una instalación física. No habrá discos físicos conectados mediante acceso directo. Para practicar particionado manual utilizaremos otra máquina o un clon, sin mezclarlo con la primera instalación automática. Referencia F6.

### 7.3. Identidad, hora y permisos

El nombre del equipo identifica la máquina; el nombre de usuario identifica una cuenta. Cambiar uno no cambia automáticamente el otro. El primer usuario puede tener permiso para administrar mediante sudo, pero las tareas ordinarias se realizan sin elevación.

Europe/Madrid permite aplicar la zona horaria correspondiente. Una hora incorrecta puede causar fallos de certificados, actualizaciones o registros difíciles de comparar. Si un navegador rechaza un certificado, no desactives la validación antes de revisar hora, red y mensaje exacto.

### 7.4. Comprobar de manera observable

```bash
cat /etc/os-release
uname -r
hostnamectl
timedatectl
free -h
lsblk -f
ip -br address
ip route
```

cat /etc/os-release identifica la distribución y versión. uname -r informa del kernel, no del número de versión de Ubuntu. free muestra memoria y no el tamaño del SSD. ip address muestra interfaces; una dirección 127.0.0.1 identifica la propia máquina, no la conectividad de red.

La aceptación de P2 exige arranque sin ISO, usuario funcional, escritura persistente, disco esperado, memoria coherente, reloj correcto y acceso a los repositorios. Una captura del escritorio por sí sola no permite comprobar esos criterios.

### 7.5. Qué significan las pantallas de instalación

Idioma determina textos, teclado determina qué carácter produce una tecla y zona horaria interpreta la hora local. Son decisiones distintas: elegir español no garantiza que se haya seleccionado la distribución física del teclado del puesto. Probar símbolos antes de escribir una contraseña evita registrar una clave diferente de la que se cree haber escrito.

La selección de aplicaciones decide qué se instala inicialmente, pero no bloquea para siempre instalar otras después. La pantalla de disco tiene un efecto mucho mayor: puede crear tabla, formatear y cambiar el arranque. Por eso se detiene el procedimiento en el resumen de cambios y se comprueba el destino antes de confirmar.

### 7.6. La contraseña de sudo y las comprobaciones

En una terminal, sudo puede solicitar la contraseña sin dibujar asteriscos. La ausencia de caracteres visibles es un comportamiento habitual. Después de ejecutar una orden administrativa hay que leer su resultado; que vuelva el prompt no demuestra por sí solo que todo haya terminado correctamente.

La prueba de persistencia debe recorrer un reinicio real desde disco. Suspender o guardar estado puede conservar una sesión Live y ocultar la diferencia. Por eso se retira la ISO, se apaga o reinicia según la práctica y se vuelve a localizar el archivo dentro del sistema instalado.

## B8. Windows 11: instalación y aceptación
### 8.1. Preparar el invitado

La máquina de Windows tendrá su propio disco. La propuesta de laboratorio es 2 vCPU, entre 4 y 6 GiB de RAM según el anfitrión y un VDI dinámico de 80 GiB. Verifica los requisitos vigentes de la edición descargada y la compatibilidad del hipervisor. No se utilizarán modificaciones del registro para omitirlos.

Registra UEFI, TPM virtual y la configuración de Secure Boot aplicable. Si la edición no puede instalarse con el hardware disponible, se documenta la limitación y se utiliza un puesto compatible del aula. El aprendizaje incluye detectar que un encargo no es viable con unos recursos determinados.

### 8.2. Particiones y configuración inicial

En una instalación limpia sobre disco vacío, permite al instalador crear su distribución de particiones y después interprétala. No esperes que todas tengan letra. La configuración inicial de red y cuentas depende de edición, versión y políticas del centro: prepara la identidad de aula antes de empezar y no utilices credenciales personales en una imagen que se exportará.

La activación y la instalación son procesos relacionados, pero distintos. Un sistema que ha llegado al escritorio puede seguir pendiente de activación. El informe registra el estado sin fotografiar ni publicar claves.

### 8.3. Comprobaciones

En Windows abre Información del sistema, Administrador de dispositivos, Administración de discos y Windows Update. Comprueba versión mediante winver, firmware y arranque seguro en msinfo32 y TPM mediante tpm.msc cuando esté disponible. Distingue «compatible», «habilitado» y «no disponible» según lo que realmente indiquen las herramientas.

En PowerShell:

```powershell
Get-Disk
Get-Partition
Get-Volume
Get-NetIPConfiguration
```

No ejecutes comandos de eliminación ni inicialización para consultar el estado. Una comprobación de lectura permite describir el equipo sin alterar particiones. Registra dispositivos desconocidos y revisa controladores de integración si aparecen. Completa actualizaciones y reinicios antes de crear el estado base de la VM.

### 8.4. Instalar aplicaciones en Windows: MSI y EXE

MSI es un formato de paquete gestionado mediante Windows Installer. Un EXE es un ejecutable que puede contener un instalador propio, un lanzador u otro programa. La extensión no certifica la procedencia ni garantiza seguridad. Antes de ejecutar, se revisan origen, editor, arquitectura y propósito.

Una instalación puede necesitar permisos, cerrar programas o reiniciar. Leer el asistente implica identificar carpeta, componentes y opciones adicionales, no aceptar todo por velocidad. Después se comprueba la aplicación y se registra cómo desinstalarla desde **Configuración → Aplicaciones → Aplicaciones instaladas** o mediante el procedimiento indicado.

No se presupone que un MSI vaya a crear siempre un punto de restauración ni que todos los EXE permitan instalaciones simultáneas. El comportamiento depende de protección del sistema, paquete y políticas. La prueba de aceptación se basa en el resultado real del puesto.

## B9. Redes virtuales con una finalidad
### 9.1. Las preguntas que decide una red

Antes de elegir modo, determina quién debe iniciar la comunicación: invitado hacia Internet, anfitrión hacia invitado o un invitado hacia otro. NAT individual sirve para salida habitual; no crea por defecto una red compartida entre todas las VM. Red NAT permite agrupar invitados con salida. Solo anfitrión comunica el anfitrión y las VM de esa red, sin salida exterior por ese adaptador. Red interna comunica las VM conectadas al mismo nombre de red. Puente incorpora el invitado a la red física y requiere permiso del centro. Referencia F7.

### 9.2. Diseño del laboratorio

| Modo | Salida a Internet | Inicio desde anfitrión | Comunicación entre invitados |
| --- | --- | --- | --- |
| NAT individual | Sí, según red del anfitrión | Con reenvío para el servicio | No como red compartida por defecto |
| Red NAT | Sí, según configuración | Con reenvío para el servicio | Sí, en la misma Red NAT |
| Solo anfitrión | No por ese adaptador solo | Sí, en esa red | Sí, en esa red |
| Red interna | No por ese adaptador solo | No directamente | Sí, con el mismo nombre de red |
| Puente | Según la red física | Según red y firewall | Según red y firewall |

La tabla resume el comportamiento ordinario sin rutas adicionales. «Sí» no garantiza que un servicio esté activo ni permitido por el firewall. NAT facilita conexiones salientes, pero no debe interpretarse como una política completa de aislamiento frente a todos los recursos del anfitrión o de la LAN.

Utilizaremos NAT para descargar y una red solo anfitrión para acceder a una web del invitado. Con dos adaptadores, cada uno cumple un propósito. El adaptador NAT obtiene normalmente configuración por DHCP. En el adaptador de laboratorio se utiliza la subred aprobada, sin una segunda puerta de enlace por defecto.

Ejemplo: anfitrión 192.168.56.1/24; Ubuntu 192.168.56.10/24; segundo invitado 192.168.56.11/24. Son direcciones de ejemplo: comprueba que no colisionan con la red real, una VPN u otra red virtual. Desactiva DHCP en esa red si se asignan manualmente esas direcciones, o acuerda un rango que no las solape.

### 9.3. IP, puerta de enlace y DNS

La IP identifica una interfaz en una red. La máscara determina qué destinos se consideran locales. La puerta de enlace permite salir hacia otras redes. DNS traduce nombres a direcciones. Tener IP no demuestra que DNS funcione; que falle un ping a un nombre tampoco prueba que «Internet está caído».

Diagnostica por capas: interfaz activa, dirección y máscara, ruta, resolución de nombre y servicio final. Un servidor puede rechazar ICMP y aceptar HTTPS. La aceptación se basa en la comunicación que necesita la tarea, no en un único ping.

### 9.4. Publicar un servicio de prueba

En Ubuntu, dentro de una carpeta que contenga solamente archivos del ejercicio:

```bash
mkdir -p ~/ud4-web
cd ~/ud4-web
printf '<h1>Laboratorio UD4</h1>\n' > index.html
python3 -m http.server 8000 --bind 0.0.0.0
```

El proceso se queda activo en la terminal; se detiene con Ctrl+C. 0.0.0.0 indica escucha en las interfaces IPv4 disponibles. En una red solo anfitrión, abre desde el anfitrión http://192.168.56.10:8000 usando la IP real. No es un servidor de producción. Si hay firewall, autoriza exclusivamente el tráfico necesario en la red de laboratorio.

Con NAT individual puedes definir reenvío TCP desde 127.0.0.1:8080 del anfitrión al puerto 8000 del invitado. Entonces el navegador del anfitrión abre http://127.0.0.1:8080. Esta dirección representa al anfitrión para ese navegador; la regla decide qué servicio del invitado recibe la conexión.

### 9.5. Diagnosticar con dos navegadores y una terminal

La primera petición se hace desde el invitado a su bucle local: comprueba proceso y puerto sin atravesar la red virtual. La segunda llega desde el anfitrión a la IP del adaptador de laboratorio: añade tarjeta, dirección, ruta y firewall. La tercera utiliza el bucle local del anfitrión y una regla NAT: comprueba además la traducción de puerto.

Comparar estos resultados permite acotar un fallo. Si no responde ni dentro del invitado, el primer sospechoso es el servicio, su carpeta o su puerto. Si funciona allí pero no por la ruta externa, no hay que reinstalar Ubuntu: se revisan las condiciones que esa segunda ruta incorpora.

## B10. Actualizar, instalar aplicaciones y validar
### 10.1. Repositorios y dependencias

Un repositorio ofrece paquetes y metadatos. El gestor consulta esa información y resuelve dependencias. Una aplicación puede necesitar bibliotecas y servicios adicionales: instalar un único archivo no siempre basta. Añadir un repositorio amplía las fuentes de software en las que confías; no es una solución automática a cualquier error.

No todo archivo tar.gz es un instalador ni todo paquete utiliza versionado semántico. Un número como 2.4.1 puede seguir una convención del proyecto; hay que consultar su política. Las actualizaciones de seguridad pueden mantener gran parte del número de versión y aun así corregir vulnerabilidades.

### 10.2. APT con comprensión

```bash
sudo apt update
apt list --upgradable
sudo apt upgrade
apt show tree
sudo apt install tree
tree --version
```

update refresca información; no actualiza por sí solo los programas instalados. upgrade instala actualizaciones y puede añadir dependencias, pero no elimina paquetes existentes. full-upgrade puede eliminar paquetes para resolver cambios. No se utilizará sin revisar su propuesta. remove y purge también se distinguen por el tratamiento de configuración de paquetes, y no garantizan borrar datos del directorio personal. Referencia F8.

Lee lo que el gestor propone antes de aceptar. Si hay un bloqueo porque otra actualización sigue trabajando, espera y consulta el proceso. Borrar archivos de bloqueo a ciegas puede dejar una operación inconsistente. Si falla la descarga, comprueba red, DNS, reloj, espacio y repositorios antes de intentar reinstalar todo.

### 10.3. Windows Update y reinicios

En Windows registra estado inicial, actualizaciones propuestas y estado posterior al reinicio. Si una actualización requiere reiniciar, el trabajo no ha terminado hasta comprobar que el sistema vuelve a arrancar y funciona. En un aula, centraliza descargas o programa tandas para no saturar la red.

### 10.4. Criterios de aceptación

Una aceptación profesional contiene pruebas y resultados. «Funciona» no basta. Ejemplo: «Tras reiniciar sin ISO, inicio sesión como alumno; index.html permanece; la herramienta tree devuelve versión; se accede al repositorio; no quedan reinicios pendientes observados; el sistema muestra la fecha correcta».

Compara con una línea base: antes/después, versiones y cambios. Una captura debe tener pie que explique lo que demuestra. No se valorará acumular imágenes sin interpretación. Continúa con P6.

### 10.5. Formatos de paquete: qué identifica cada uno

Un DEB es un paquete usado en sistemas como Debian y Ubuntu; RPM pertenece a otra familia de gestores. No se instala un RPM con APT por cambiarle la extensión. Un archivo tar.gz es un archivo comprimido: puede contener código, binarios, datos o documentación; hay que inspeccionar qué ofrece el proyecto. Un ebuild es una descripción de construcción propia de Gentoo, no un paquete intercambiable con DEB.

En `programa_version_arquitectura.deb`, nombre del archivo y nombre del paquete están relacionados, pero no son la misma cadena. Se instala un archivo local por su ruta; se consulta o elimina el paquete por su identificador. Así se evita copiar el error de pasar siempre el nombre completo del archivo a una orden de desinstalación.

### 10.6. APT, apt-get y dpkg

APT proporciona una interfaz apropiada para trabajo interactivo; apt-get ofrece opciones estables utilizadas en automatización. dpkg gestiona paquetes DEB a un nivel inferior y no descarga por sí solo toda la resolución de dependencias desde repositorios. Para un archivo local se puede utilizar `sudo apt install ./archivo.deb`, una vez verificada su procedencia.

`dpkg-deb --info archivo.deb` inspecciona el archivo. `dpkg-query -W nombre-paquete` consulta un paquete instalado. `remove` y `purge` expresan distintas decisiones sobre configuración de paquete, sin sustituir una política de borrado de datos personales. Las operaciones que propongan retirar dependencias se leen antes de aceptar.

### 10.7. Repositorios tradicionales y formato deb822

APT puede leer definiciones `.list` y `.sources` dentro de `/etc/apt/sources.list.d/`. Las primeras suelen usar líneas que comienzan por `deb`; las segundas organizan campos como `Types`, `URIs`, `Suites`, `Components` y `Signed-By`. La ruta y formato reales se consultan en el equipo: no se presupone que toda instalación use el mismo archivo histórico.

La URI identifica el origen; la suite lo relaciona con una versión o canal; los componentes organizan conjuntos de paquetes. `Signed-By` limita qué clave se acepta para ese origen cuando está configurado. Un archivo de clave no se transforma en otro formato simplemente renombrándolo. Añadir repositorios externos requiere seguir las instrucciones actuales del editor para esa distribución y revisar su confianza.

En P10 se inspeccionan los orígenes ya aprobados. No se añade WineHQ, un PPA o un origen de Chrome solo para copiar un ejemplo antiguo. Se comprueba antes necesidad, versión admitida, formato de clave y procedimiento de retirada. Cambiar la firma o ignorar errores para que la descarga continúe oculta el problema.

### 10.8. Snap y gestión gráfica de aplicaciones

Snap utiliza snapd y un modelo de distribución con canales y confinamiento según el paquete. Puede incluir dependencias y utilizar bases o componentes compartidos; no significa que cada programa lleve absolutamente todo ni que cualquier permiso esté garantizado. `snap list` consulta instalaciones; `snap info` ayuda a revisar un programa. Las aplicaciones de una tienda gráfica pueden proceder de formatos distintos: conviene identificar el origen mostrado.

Una retirada de Snap puede conservar una instantánea de datos según el comportamiento configurado. Por eso «quitar un programa» no equivale a certificar que nunca queda configuración ni datos. La copia y la política de conservación se estudian por separado.

## B11. Recuperación, clonación y arranque dual
### 11.1. Cuatro operaciones diferentes

Una instantánea conserva un punto de retorno dentro de la estructura de la VM. Un clon completo crea otra máquina con discos independientes de los del origen. Un clon enlazado necesita su base. Una exportación produce un paquete transportable con limitaciones de compatibilidad y de elementos conservados. Un respaldo independiente protege frente a la pérdida de la ubicación de trabajo si se almacena y se prueba adecuadamente.

Piensa en qué fallos cubre cada operación. Una instantánea ayuda ante un cambio defectuoso dentro del invitado; no salva los discos si falla el SSD que contiene toda la cadena. Un clon completo en ese mismo SSD es independiente del origen, pero comparte el mismo riesgo físico. Referencia F9.

### 11.2. Restaurar también pierde cambios

Al volver a una instantánea se pierde o se aparta el estado posterior según la operación elegida. Antes de restaurar, extrae las evidencias que necesites conservar o guarda un estado adicional. Borrar una instantánea no equivale a restaurarla: el hipervisor reorganiza los datos asociados. Nunca elimines manualmente archivos diferenciales.

Una restauración no revierte efectos externos: un archivo modificado en una carpeta compartida del anfitrión, una cuenta en un servicio web o un mensaje enviado seguirán existiendo. La práctica P7 utiliza archivos internos para que el alcance sea observable.

### 11.3. Clonar y transferir

Para un clon que convivirá en red con el origen, genera nuevas MAC y revisa nombre del equipo, direcciones estáticas e identidades específicas del sistema. Una MAC nueva no cambia automáticamente todas las identidades internas. Un Windows destinado a despliegues generales requiere herramientas y procedimientos de preparación adicionales; clonar una VM de aula no constituye por sí solo un despliegue corporativo correcto.

Una exportación se considera útil cuando se importa y supera las pruebas. Conserva un inventario externo con versión de hipervisor, firmware, CPU, RAM, discos y red. No supongas que un OVA mantiene toda la historia de instantáneas, la configuración TPM, los secretos o todas las funciones específicas entre plataformas.

### 11.4. Arranque dual como ampliación

La ampliación usa una VM nueva de 120 GiB, Windows y Ubuntu en el mismo disco virtual. Primero Windows; después Linux en espacio sin asignar. Es una secuencia didáctica para observar cargadores y particiones. Comprueba el espacio libre antes de confirmar y conserva la ESP existente sin formatearla.

En un equipo físico habría que resolver además copia independiente, cifrado, claves de recuperación, controladores y política del centro. Esta unidad no pide modificar el arranque del ordenador personal. Si no aparece un menú conjunto, comprueba las entradas UEFI: la ausencia de GRUB visible no demuestra que Windows haya desaparecido.

### 11.5. Protección del sistema de Windows

Restaurar sistema trabaja sobre estado de sistema, configuración, registro y programas dentro de su alcance. No es una máquina del tiempo para cualquier documento. Se abre desde **Inicio → Crear un punto de restauración**, o mediante `SystemPropertiesProtection`. En el asistente se elige unidad, protección y nombre del punto antes de introducir un cambio.

Para aplicar un punto se puede abrir `rstrui.exe` desde **Windows + R**. La opción **Detectar programas afectados** ayuda a anticipar el efecto. Un punto puede no estar disponible si la protección no estaba activada o no se conservó. No se da por hecho que se crea automáticamente cada semana en cualquier Windows.

La práctica P11 se ejecuta en un clon con un punto de retorno adicional del hipervisor. Permite comparar mecanismos: una instantánea de VirtualBox devuelve el estado de la VM según lo que incluya; el punto de Windows tiene otro alcance. Las evidencias y las copias se guardan donde no se perderán con la operación que se quiere ensayar.

### 11.6. Timeshift y archivos personales en Linux

Timeshift se orienta a instantáneas de sistema y admite modalidades según configuración y sistema de archivos. Su elección requiere revisar qué se incluye, qué se excluye y dónde se almacena. No debe equipararse sin matices a una copia de todos los documentos de cada usuario. Un modo basado en Btrfs necesita una disposición compatible; no se activa solo porque sea una opción visible.

Si el centro lo utiliza, antes de crear una instantánea se identifican modo, destino, filtros y recuperación desde un medio alternativo. Si las copias residen en el mismo disco que se avería, no cubren la pérdida física de ese disco. Para el laboratorio básico utilizamos las instantáneas del hipervisor; una ampliación con Timeshift se prepara en otra VM y con un objetivo de recuperación definido.

## B12. Contenedores como conexión con DAM
### 12.1. Imagen, contenedor y volumen

Una imagen es una plantilla para crear contenedores. Un contenedor es una instancia con procesos y una capa de escritura. Un volumen permite conservar datos con un ciclo de vida separado del contenedor. Una etiqueta ayuda a elegir imagen, pero puede cambiar de contenido; para máxima reproducibilidad se registra también su digest.

Un contenedor detenido puede conservar su capa de escritura hasta que se elimina. Al eliminarlo, no debes confiar en esa capa para conservar datos importantes. Un volumen no se borra simplemente por recrear el contenedor, pero también necesita respaldo si contiene información valiosa.

### 12.2. Aplicación de aula

En la ampliación X2 se ejecuta un servidor web dentro de la VM Ubuntu. La instalación del motor sigue la documentación oficial elegida por el docente; no se mezclan paquetes incompatibles ni se pega un script remoto sin revisarlo. Se utilizan comandos con sudo, sin añadir a toda la clase al grupo docker como si fuera un permiso ordinario.

Publicar 127.0.0.1:8081:80 hace accesible el puerto 80 del contenedor a través de 8081 en el bucle local de la VM. Desde el anfitrión físico, 127.0.0.1 identifica otro sistema; por eso la prueba inicial se hace con el navegador de Ubuntu. Esta distinción enlaza con las redes de P5.

### 12.3. Qué comparar

Compara kernel, tiempo de preparación, espacio y persistencia. No concluyas que un contenedor equivale a instalar un sistema completo. Tampoco concluyas que siempre es más adecuado: para aprender el instalador y el arranque de Windows o Linux se necesita un sistema invitado completo. Las aplicaciones web son un contexto apropiado para explorar la alternativa de contenedores. Referencias F10 y F11.

### 12.4. Interpretar la publicación de puertos

En `127.0.0.1:8081:80`, la primera parte es la dirección de escucha del sistema que ejecuta el motor, la segunda es su puerto publicado y la tercera el puerto del contenedor. En X2 el motor está dentro de Ubuntu virtualizado. El navegador de esa Ubuntu puede usar 127.0.0.1:8081; el del ordenador físico utiliza su propio bucle local y necesitaría otra ruta para llegar.

Esto permite razonar la diferencia entre que un proceso esté en ejecución y que un cliente pueda alcanzarlo. También explica por qué los datos del volumen pueden seguir presentes aunque se elimine el contenedor: servicio, red y almacenamiento tienen ciclos de vida relacionados, pero separados.

## Glosario de trabajo

Arquitectura: conjunto de características que condiciona qué código puede ejecutar una CPU. Anfitrión: equipo que aporta recursos. Invitado: sistema ejecutado en una VM. Hipervisor: capa que gestiona máquinas virtuales. ISO: imagen de un medio de instalación. VDI: formato de disco virtual de VirtualBox. Firmware: software inicial que prepara y arranca el equipo. ESP: partición del sistema EFI. GPT: esquema de tabla de particiones. Montaje: incorporación de un sistema de archivos a un punto del árbol. UUID: identificador usado para localizar volúmenes. DHCP: asignación automática de parámetros IP. DNS: resolución de nombres. NAT: traducción de direcciones. Instantánea: punto de retorno dependiente de la estructura de la VM. OVA: paquete de intercambio de máquina virtual. Imagen de contenedor: base para crear instancias. Volumen: almacenamiento gestionado separadamente del contenedor.

## Fuentes y ampliación técnica

Consulta realizada el 26 de octubre de 2026. La referencia de interfaz es VirtualBox 7.x; se debe comprobar la rama instalada. Los procedimientos y actividades son una elaboración didáctica; contrasta los requisitos del producto antes de llevarlos a un aula concreta.

- F1. Canonical, verificación de descargas: https://ubuntu.com/tutorials/how-to-verify-ubuntu
- F2. Microsoft, requisitos de Windows 11 y máquinas virtuales: https://learn.microsoft.com/en-gb/windows/whats-new/windows-11-requirements
- F3. Microsoft, particiones UEFI/GPT: https://learn.microsoft.com/es-es/windows-hardware/manufacture/desktop/configure-uefigpt-based-hard-drive-partitions?view=windows-11
- F4. Oracle, configuración de máquinas virtuales: https://docs.oracle.com/en/virtualization/virtualbox/7.1/user/BasicConcepts.html
- F5. Oracle, Guest Additions: https://docs.oracle.com/en/virtualization/virtualbox/7.1/user/guestadditions.html
- F6. Canonical, instalación Ubuntu Desktop: https://ubuntu.com/tutorials/install-ubuntu-desktop
- F7. Oracle, redes virtuales: https://docs.oracle.com/en/virtualization/virtualbox/7.1/user/networkingdetails.html
- F8. Ubuntu, manual de apt: https://manpages.ubuntu.com/manpages/noble/man8/apt.8.html
- F9. Oracle, primeros pasos, instantáneas y clones: https://docs.oracle.com/en/virtualization/virtualbox/7.1/user/Introduction.html
- F10. Docker, conceptos iniciales: https://docs.docker.com/get-started/docker-concepts/the-basics/what-is-a-container/
- F11. Docker, instalación del motor en Ubuntu: https://docs.docker.com/engine/install/ubuntu/


## Fuentes complementarias

- APT y formato de orígenes: https://manpages.ubuntu.com/manpages/noble/man5/sources.list.5.html
- Restaurar sistema, Microsoft: https://support.microsoft.com/en-us/windows/experience/backup-recovery/system-restore
- Snap, documentación del proyecto: https://snapcraft.io/docs
