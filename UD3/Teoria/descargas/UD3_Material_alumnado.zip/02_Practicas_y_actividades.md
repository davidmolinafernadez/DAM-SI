# Unidad 3. Cuaderno de prácticas guiadas

Sistemas Informáticos · 1.º de DAM · Laboratorio del alumnado

## Normas de trabajo y entrega

Trabaja únicamente con las máquinas virtuales y los discos de prueba identificados en cada ficha. No conectes discos físicos directamente al invitado. Los cambios de particiones se limitan a discos virtuales vacíos o clones de laboratorio. Las contraseñas y claves de activación no se incorporan a capturas ni entregas.

Antes de empezar una práctica: lee la teoría indicada, dibuja el estado inicial y escribe una predicción. Durante el trabajo: registra decisiones y errores, sin ocultar intentos fallidos. Al terminar: ejecuta las pruebas de aceptación y explica si los resultados confirman la predicción.

Las capturas deben mostrar un dato legible, estar numeradas y llevar un pie explicativo. Para identificar la autoría, utiliza nombre de máquina y un código de alumno de aula; no es necesario exponer datos personales. Los vídeos del catálogo 03 se consultan en el momento indicado y se acompañan de preguntas. La documentación escrita prevalece si el vídeo utiliza una interfaz antigua o simplifica un concepto.

Carpeta de entrega por práctica: Pxx_codigo. Incluye informe.pdf, evidencias y, cuando se pida, archivos de texto de configuración. No entregues ISO ni discos virtuales de decenas de gigabytes en la plataforma salvo indicación docente. La demostración práctica del equipo sirve para evaluar el funcionamiento.


Las actividades escritas tienen su propio cuaderno y sus propias páginas. Aquí se recogen únicamente procedimientos de ejecución, comprobación y diagnóstico del laboratorio. Las rutas de menú se refieren a las versiones de referencia; el docente indicará las diferencias de la imagen del aula.

## P0. Auditoría del puesto e ISO verificada

Duración orientativa: 90 minutos. Trabajo individual. Necesitas Windows en el anfitrión, acceso a sus datos de hardware y una carpeta para el laboratorio. No se modifica el firmware del ordenador del aula.

### 1. Abre las herramientas del anfitrión

1. Pulsa **Ctrl + Mayús + Esc** para abrir el **Administrador de tareas**. Si aparece una vista reducida, pulsa **Más detalles**.
2. Abre **Rendimiento → CPU**. Anota modelo, núcleos, procesadores lógicos y estado de **Virtualización**. Un estado habilitado indica lo que informa Windows; no demuestra por sí solo que cualquier combinación de hipervisores vaya a funcionar.
3. Abre **Rendimiento → Memoria**. Distingue memoria total y disponible. La disponible cambia mientras abres programas: anota el momento de la medición.
4. Pulsa **Windows + E → Este equipo**. Localiza la unidad donde se guardarán las VM. Pulsa su botón derecho → **Propiedades** y anota espacio libre. Esa cifra no es RAM.
5. Pulsa **Windows + R**, escribe `msinfo32` y pulsa **Aceptar**. En **Resumen del sistema**, consulta tipo de sistema y modo de BIOS. El modo del anfitrión no obliga a utilizar el mismo firmware en todos sus invitados.

### 2. Decide si el laboratorio cabe

Abre tu documento de entrega y crea una tabla con las filas: anfitrión, Ubuntu, Windows y margen. Separa RAM, CPU y almacenamiento. Explica si ejecutarás los invitados simultáneamente o de forma alterna. Utiliza las cifras propuestas por el docente como punto de partida, no como permiso para asignar toda la memoria disponible.

Para un anfitrión de 16 GiB puedes estudiar una reserva de 6 GiB para Windows y aplicaciones, 4 para Ubuntu, 4 para el invitado Windows y 2 de margen. Después tendrás que medir. Para un equipo de 8 GiB plantea un solo invitado activo y consulta dónde realizar la práctica de Windows si no cumple requisitos.

### 3. Descarga e identifica el medio

1. Abre el navegador y entra en la página oficial indicada en la teoría. Selecciona **Ubuntu Desktop**, la versión acordada y arquitectura **amd64** para el laboratorio x86-64. No confundas amd64 con un requisito de procesador de marca AMD.
2. Guarda la ISO en una carpeta identificable, por ejemplo `ISO_UD3`. Desde el Explorador abre **Ver → Mostrar → Extensiones de nombre de archivo**, si está disponible, para comprobar la extensión real.
3. Anota el nombre completo del archivo, tamaño, versión, arquitectura, fecha y URL. No renombres el archivo antes de cotejar su referencia.
4. Abre el listado oficial de hashes de esa misma revisión. Localiza la fila del nombre exacto de tu ISO. Si el centro proporciona el archivo, también debe proporcionar su procedencia y referencia.

### 4. Calcula la huella en PowerShell

Entra en la carpeta `ISO_UD3`. Pulsa la barra de direcciones del Explorador, escribe `powershell` y pulsa **Intro**. Se abre una consola situada en esa carpeta. Ejecuta `Get-ChildItem` para comprobar qué archivos contiene.

Escribe el comando siguiente sustituyendo el nombre por el de tu ISO. Puedes escribir el comienzo del nombre y pulsar **Tab** para completarlo:

```powershell
Get-FileHash -LiteralPath '.\NOMBRE_REAL_DE_LA_IMAGEN.iso' -Algorithm SHA256
```

El texto `NOMBRE_REAL_DE_LA_IMAGEN.iso` es un marcador, no un archivo que exista. Compara los 64 caracteres del resultado con la referencia. Que coincidan el principio y el final no basta. Copia ambas cadenas como texto en el informe y explica qué confianza aporta su procedencia.

### 5. Comprueba y entrega

Debes entregar ficha del puesto, presupuesto razonado, identificación de ISO y comparación completa. Si la huella no coincide, no uses la imagen: comprueba revisión, nombre y descarga. La ampliación de firma digital se realiza con la guía oficial, verificando la identidad de la clave.

**Incidencia para analizar:** el archivo se llama igual que el de la referencia, pero tiene otra huella. Propón dos explicaciones y una prueba para distinguirlas. No respondas solamente «está mal».

## P1. Crear y entender la máquina virtual

Duración orientativa: 120 minutos. Necesitas VirtualBox 7.x instalado, la ficha de P0 y la ISO verificada. El docente indicará la versión exacta. Los nombres de algunas secciones varían entre el modo básico y el experto; identifica la función del campo antes de modificarlo.

### 1. Reconoce las dos ventanas

Abre **Inicio**, escribe **VirtualBox** y abre el administrador. Esta ventana lista las máquinas y permite configurar su hardware. La ventana que aparecerá al pulsar **Iniciar** será la pantalla del ordenador invitado: sus menús y su sistema son distintos de los del anfitrión.

En el administrador abre **Ayuda → Acerca de VirtualBox** y anota la versión. Abre **Archivo → Preferencias → General** si tu versión muestra esa ruta y consulta la carpeta predeterminada de máquinas. En otras interfaces se encuentra en las preferencias de la aplicación. No cambies la carpeta de otras máquinas ya existentes.

### 2. Abre el asistente de creación

1. Pulsa **Nueva** en la barra principal, o **Máquina → Nueva**. Escribe `UD3-Ubuntu-codigo`, sustituyendo `codigo` por tu identificador de aula.
2. En **Carpeta**, elige la ubicación local aprobada. No uses una carpeta de otra persona ni un dispositivo con espacio insuficiente.
3. Deja inicialmente el campo **Imagen ISO** sin imagen. Si seleccionas una y aparece **Omitir instalación desatendida**, márcalo: necesitamos recorrer el instalador en P2.
4. Selecciona **Linux → Ubuntu de 64 bits** o la identificación equivalente de la plantilla. La plantilla propone hardware; todavía no instala Ubuntu.
5. En **Hardware**, asigna **4096 MB** de memoria y **2 procesadores** si P0 justifica esa cantidad. Registra cualquier ajuste acordado. En el campo de memoria, 4096 MiB corresponden a 4 GiB.
6. En **Disco duro**, elige crear un disco nuevo, formato **VDI** y capacidad **50 GiB** o su equivalente mostrado. Mantén la asignación dinámica: no marques **Reservar tamaño completo** si la interfaz ofrece esa casilla.
7. Revisa el resumen y pulsa **Terminar**. Selecciona la máquina recién creada; comprueba el nombre antes de continuar.

### 3. Revisa la configuración antes de arrancar

Pulsa **Configuración → Sistema → Placa base**. Activa **EFI/UEFI** para el itinerario de referencia si aún no está activado. Revisa el orden de arranque. En **Sistema → Procesador**, comprueba los dos procesadores virtuales. En **Red → Adaptador 1**, marca **Habilitar adaptador de red** y selecciona **NAT** en **Conectado a**. Si aparece **Cable conectado**, debe estar marcado.

Abre **Almacenamiento**. Debes ver un disco virtual de 50 GiB y una unidad óptica vacía. No elimines controladores por confundirlos con medios. La unidad óptica recibirá la ISO; el disco duro recibirá el sistema instalado.

### 4. Compara un arranque sin y con instalador

1. Cierra la configuración con **Aceptar** y pulsa **Iniciar**. Con disco vacío y sin ISO puedes ver el firmware o un aviso de medio no arrancable. Registra lo observado: no hay un mensaje único obligatorio.
2. Cierra la ventana de ejecución. Como no hay un sistema instalado que apagar, utiliza **Apagar la máquina** cuando el diálogo lo ofrezca. Este es un caso de ensayo con disco vacío, no la forma ordinaria de cerrar un sistema en uso.
3. De vuelta en el administrador, abre **Configuración → Almacenamiento**. Selecciona la unidad óptica **Vacío**, pulsa el icono de disco de la derecha y elige **Seleccionar un archivo de disco**. Busca la ISO de P0 y ábrela.
4. Comprueba que su nombre aparece junto a la unidad óptica y pulsa **Aceptar → Iniciar**. Ahora debe aparecer el medio de Ubuntu. Todavía no realices la instalación.

### 5. Ubica los archivos y comprueba el resultado

Con la VM apagada, pulsa su botón derecho en el administrador y utiliza **Mostrar en Explorador**, o abre la carpeta anotada en el asistente. Identifica `.vbox`, `.vdi` y la carpeta de registros. No los borres ni los edites. Compara tamaño actual del VDI con capacidad lógica configurada.

Entrega la ficha técnica, la comparación de los dos arranques y una explicación propia de ISO frente a VDI. **Prueba de aceptación:** otra persona puede reconstruir una configuración equivalente usando tu ficha. **Incidencia:** si no arranca el medio, comprueba primero si la ISO está en la unidad óptica de esta VM y si es arrancable y compatible con su arquitectura.

## P2. Ubuntu Desktop: de la ISO al sistema instalado

Duración orientativa: 180 minutos. Estado inicial: máquina de P1, un único VDI vacío de 50 GiB, NAT y Ubuntu Desktop 24.04 LTS. Esta guía describe la secuencia habitual; alguna pantalla puede cambiar de posición según la revisión. Nunca confirmes un borrado sin identificar el destino.

### 1. Arranca el medio y reconoce el modo Live

Selecciona `UD3-Ubuntu-codigo` en el administrador y pulsa **Iniciar**. En el menú de Ubuntu selecciona **Try or Install Ubuntu** con las flechas y pulsa **Intro**. Espera a que cargue. Si llegas al escritorio sin instalador abierto, haz doble clic en **Install Ubuntu / Instalar Ubuntu**.

El escritorio de prueba se ejecuta desde el medio. Abrir Firefox en él no acredita una instalación en disco. La comprobación final consistirá en retirar la ISO y reiniciar conservando un archivo.

### 2. Recorre las decisiones iniciales

1. Selecciona **Español** y pulsa **Siguiente**. En accesibilidad activa las opciones que necesites; en caso contrario continúa.
2. En **Distribución del teclado**, selecciona la del puesto. Utiliza el cuadro de prueba: escribe `ñ`, `@`, `/` y algún signo. Si no coinciden, cambia la distribución antes de crear una contraseña.
3. En conexión de red, utiliza la conexión cableada virtual disponible por NAT. Puede aparecer como cable aunque el anfitrión esté conectado por Wi-Fi.
4. Si se ofrece actualizar el propio instalador, sigue la decisión del docente y espera a que termine. No lo confundas con haber actualizado todo el sistema instalado.
5. Cuando pregunte qué quieres hacer, selecciona **Instalar Ubuntu**. En modalidad, elige **Instalación interactiva**. El archivo de instalación automática no forma parte de esta primera experiencia.
6. En selección de aplicaciones, elige la opción acordada. Anota si instalas una selección predeterminada o ampliada. Decide con el docente las descargas adicionales y el software de terceros; la red del aula puede aconsejar posponerlos.

### 3. Identifica el disco antes de confirmar

En el apartado de configuración del disco selecciona **Borrar disco e instalar Ubuntu** solo después de verificar que es el VDI vacío de 50 GiB de esta VM. Si aparecen discos inesperados o capacidad distinta, vuelve atrás: no se resuelve eligiendo uno al azar.

Abre las opciones avanzadas si necesitas comprobar qué modalidad se aplicará. En la primera instalación usa el reparto automático acordado, sin activar cifrados o LVM que el grupo todavía no haya preparado. El particionado manual se practica después en un disco identificado. Anota qué disco va a cambiar y qué datos contiene actualmente.

### 4. Identidad, ubicación e instalación

Rellena tu nombre de aula, nombre del equipo y usuario. Usa minúsculas y un nombre sencillo para el usuario, por ejemplo `alumno`; el nombre de máquina puede ser `ud3-ubuntu-codigo`. Introduce la contraseña prevista sin incluirla en capturas. Selecciona **Madrid** o la zona **Europe/Madrid** en el mapa o búsqueda de ubicación.

En el resumen final lee el dispositivo afectado y los cambios previstos. Haz una captura recortada a esa información, explica por qué el destino es correcto y pulsa **Instalar**. Durante la copia no cierres la ventana ni fuerces el apagado. El orden exacto de identidad, ubicación y disco puede variar; el requisito es revisar todos los datos antes de la confirmación destructiva.

### 5. Retira la ISO y comprueba un arranque independiente

Cuando el instalador termine pulsa **Reiniciar ahora**. Si solicita retirar el medio, utiliza el menú de la ventana del invitado **Dispositivos → Unidades ópticas → Retirar disco de la unidad virtual** y pulsa **Intro** cuando proceda. Si la unidad no se deja liberar, apaga la VM y realiza la retirada desde **Configuración → Almacenamiento**, seleccionando la ISO y el icono de disco → **Retirar disco**. No elimines el VDI.

Arranca otra vez. Debe aparecer el Ubuntu instalado y la cuenta configurada. Si vuelves a ver el instalador, revisa medio y orden de arranque. No repitas la instalación para resolver un medio aún conectado.

### 6. Abre la terminal y crea una prueba persistente

Dentro de Ubuntu pulsa **Ctrl + Alt + T**. Esta combinación abre una terminal del invitado cuando el foco está dentro de su escritorio. Si el atajo lo captura el anfitrión, abre **Mostrar aplicaciones**, busca **Terminal** y ejecútala.

```bash
printf 'Mi sistema instalado de la UD3\n' > ~/comprobacion-ud3.txt
cat ~/comprobacion-ud3.txt
cat /etc/os-release
hostnamectl
timedatectl
free -h
lsblk -f
ip -br address
ip route
```

Ejecuta una orden cada vez. `printf` crea un archivo en tu carpeta personal; `cat` permite leerlo. Interpreta distribución, nombre, hora, memoria, discos y red. No entregues una captura de diez órdenes sin explicar sus resultados.

Abre el menú de estado de la esquina superior derecha de Ubuntu y selecciona **Apagar/Cerrar sesión → Reiniciar**, según el texto disponible. Tras volver a iniciar sesión, abre la terminal y lee de nuevo el archivo. Debe conservar su contenido.

### 7. Integración y aceptación

La instalación de Guest Additions se realiza solo mediante la ruta aprobada del centro. En la ventana de la VM se encuentra **Dispositivos → Insertar imagen de CD de Guest Additions**. Los complementos se instalan dentro del invitado; el Extension Pack no es su sustituto. Si se necesitan módulos, cabeceras o firma con Secure Boot, registra el resultado y utiliza el procedimiento docente, sin cambiar la seguridad del anfitrión.

Aceptación: arranque sin ISO, usuario correcto, archivo persistente, raíz en el disco, recursos y reloj coherentes. Entrega resumen de destino, tabla de comprobaciones y evidencia tras reinicio. **Incidencia:** explica cómo distinguir sesión Live, ISO aún conectada y disco no instalado utilizando una prueba para cada hipótesis.

## P3. Windows 11 con instalación y licencia diferenciadas

Duración orientativa: 180 minutos. Necesitas una ISO oficial, una edición y derecho de uso autorizados y el método de cuenta preparado por el docente. No se usan cuentas personales en imágenes compartidas. Si el puesto no cumple los requisitos, se utiliza un equipo compatible; no se eluden con modificaciones del registro.

### 1. Prepara el hardware de la VM

En VirtualBox pulsa **Nueva**. Escribe `UD3-Windows-codigo`, selecciona la ISO y la plantilla Windows 11 de 64 bits. Marca **Omitir instalación desatendida** si aparece. Asigna **2 vCPU**, **4-6 GiB de RAM** según P0 y crea un **VDI dinámico de 80 GiB**. Antes de encender, comprueba que Ubuntu no esté consumiendo recursos que el presupuesto necesite.

Selecciona la VM → **Configuración → Sistema**. Revisa **EFI/UEFI**, **TPM virtual 2.0** y opciones de **Secure Boot/Arranque seguro** disponibles para tu versión. No basta elegir el nombre «Windows 11» si la configuración real no cumple. Si no encuentras esas opciones, anota versión y configuración y consulta la compatibilidad con el docente.

### 2. Abre el instalador y elige el destino

1. Pulsa **Iniciar**. Si aparece «Press any key to boot from CD or DVD», pulsa una tecla dentro de la ventana para arrancar desde la ISO.
2. Selecciona idioma y teclado. Continúa mediante **Siguiente** y la opción de instalar que muestre esa revisión.
3. Identifica edición. Introduce la clave por el método del centro o aplázala si el instalador y el procedimiento acordado lo permiten. «No tengo clave» no concede por sí mismo una licencia de evaluación.
4. Revisa y acepta las condiciones aplicables bajo las indicaciones del centro. Elige la modalidad de instalación nueva o personalizada. Algunas revisiones presentan pantallas distintas a las del material antiguo: identifica la función, no solo el número de pantalla.
5. En la selección del destino comprueba que la capacidad corresponde al disco virtual de 80 GiB vacío. No debe aparecer un disco personal. Selecciona su **espacio sin asignar** y deja al instalador crear las particiones que necesite.
6. Antes de confirmar, anota destino y efecto sobre datos. Espera a la copia y a los reinicios. Cuando el disco ya esté instalado, no vuelvas a pulsar una tecla para iniciar otra instalación desde el CD.

### 3. Completa el primer inicio

Selecciona región, teclado y red. En la cuenta utiliza el procedimiento preparado para la edición del centro. Si aparece una exigencia de organización, Internet o cuenta distinta de la prevista, registra la pantalla y consúltalo: no introduzcas credenciales personales ni utilices instrucciones antiguas para ocultar el requisito.

Tras llegar al escritorio, apaga desde **Inicio → botón de encendido → Apagar**. En VirtualBox retira la ISO desde **Configuración → Almacenamiento** y arranca de nuevo. Crea un archivo de prueba en **Explorador → Documentos**, reinicia desde **Inicio** y comprueba que permanece.

### 4. Abre las herramientas de comprobación

Pulsa **Windows + R** dentro de Windows invitado. Ejecuta por separado:

- `winver`: identifica edición y versión.
- `msinfo32`: en **Resumen del sistema**, consulta modo de firmware y estado observado de arranque seguro.
- `tpm.msc`: identifica si el TPM se muestra disponible y su versión.
- `diskmgmt.msc`: abre **Administración de discos**; observa la zona inferior para interpretar particiones pequeñas, sistema y recuperación.
- `devmgmt.msc`: abre **Administrador de dispositivos** y busca iconos de advertencia.

Estas consultas no requieren inicializar ni eliminar discos. Si Administración de discos ofrece inicializar algún dispositivo inesperado, cancela y consulta cuál es antes de escribir.

### 5. Actualiza y cierra la instalación

Abre **Inicio → Configuración → Windows Update → Buscar actualizaciones**. Anota estado, instala lo acordado y utiliza **Reiniciar ahora** cuando lo solicite. Vuelve a la misma página al iniciar para comprobar el estado posterior. En **Configuración → Sistema → Activación**, registra el estado sin mostrar claves.

Si se requieren Guest Additions, en el menú de la VM abre **Dispositivos → Insertar imagen de CD de Guest Additions**. En el invitado abre **Explorador → Este equipo → unidad de CD** y utiliza el instalador correspondiente bajo el procedimiento del docente. Reinicia y comprueba si la resolución se adapta y si quedan dispositivos con incidencia.

Aceptación: arranque independiente, archivo persistente, requisitos acreditados, particiones explicadas y actualizaciones comprobadas. Una activación pendiente se declara y se resuelve por el centro; no se presenta como evaluación oficial. Entrega una tabla de herramienta, dato real y conclusión. Analiza aparte una ficha ficticia con 2 GiB de RAM, sin TPM virtual y firmware heredado.

## P4. Particionar y montar un disco de datos

Duración orientativa: 150 minutos. Se trabaja con un **VDI nuevo de 8 GiB** añadido a Ubuntu. El disco de sistema de 50 GiB queda excluido de cualquier formato. Antes de escribir, compara nombre, tamaño y montajes.

### 1. Añade el disco desde VirtualBox

Apaga Ubuntu desde su menú. En el administrador comprueba el estado **Apagada**. Abre **Configuración → Almacenamiento** y selecciona el controlador al que se conectan los discos duros, normalmente SATA. Pulsa el icono de **Añadir disco duro**; si ofrece un selector de medios, pulsa **Crear**. Crea `UD3-DATOS-codigo.vdi`, formato VDI, asignación dinámica y capacidad de **8 GiB**. Selecciona ese archivo y confirma que quedan conectados el disco de sistema y el nuevo.

Arranca Ubuntu y pulsa **Ctrl + Alt + T**. Ejecuta:

```bash
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS
```

Identifica el disco de 8 GiB sin sistemas montados. El disco que contiene `/` no se toca. El nombre puede ser `sdb`, pero no debes darlo por supuesto: depende del controlador y del orden de detección.

### 2. Abre Discos e identifica el destino otra vez

Pulsa **Mostrar aplicaciones**, busca **Discos** y abre la herramienta. Si no está instalada, el docente indicará la herramienta alternativa antes de continuar. Selecciona en la columna izquierda el dispositivo de **8 GiB**. Contrasta su capacidad con `lsblk` y haz una captura del destino antes del formato.

En **Discos**, utiliza el menú de opciones del dispositivo —normalmente tres puntos en la parte superior— → **Formatear disco**. Esta opción crea o reemplaza la tabla del disco entero; no es lo mismo que formatear una sola partición. Elige **GPT** como esquema y confirma únicamente sobre el dispositivo vacío de 8 GiB. No selecciones borrado seguro completo.

### 3. Crea una partición ext4 de aproximadamente 4 GiB

Selecciona el espacio libre de ese dispositivo y pulsa **+**. Escribe una capacidad cercana a **4 GiB**, comprobando si el cuadro usa GiB, GB o MB. Continúa y elige formato **ext4**, con etiqueta `UD3_DATOS`. Si la interfaz no lo muestra inicialmente, utiliza **Otro** para localizarlo. Confirma y espera a que finalice.

Observa que queda una partición con sistema de archivos y otra zona sin asignar. No es un error: queremos distinguir capacidad del disco y capacidad del volumen. Si utilizas GParted, selecciona el disco en el desplegable superior, después **Dispositivo → Crear tabla de particiones → gpt**, y crea la partición mediante **Partición → Nueva**. En GParted revisa las operaciones pendientes y aplica con el botón de confirmación; no mezcles operaciones de ambas herramientas a la vez.

### 4. Monta, escribe y desmonta

Con la partición seleccionada en **Discos**, pulsa el botón triangular de montar. Anota la ruta que aparece como **Montado en**. También puedes abrir **Archivos → Otras ubicaciones** y seleccionar el volumen de datos. Ejecuta `findmnt` y `df -hT` para observar qué volumen está realmente montado.

Intenta crear `prueba-persistencia.txt` dentro de ese volumen. Si el directorio pertenece a root y tu usuario no puede escribir, no cambies permisos de todo `/media`. Primero comprueba el punto exacto con `findmnt`; después ajusta el propietario de la raíz de ese volumen mediante el procedimiento supervisado. Escribir en tu carpeta personal no demuestra que hayas escrito en el disco secundario.

Vuelve a Discos y pulsa el botón cuadrado de **Desmontar**. Monta otra vez y abre el archivo. Apaga y reinicia; si el volumen no se monta automáticamente, vuelve a montarlo desde la interfaz y comprueba el mismo contenido. Los datos persistentes y el montaje automático son propiedades distintas.

### 5. Aceptación y ampliación

Entrega mapas antes/después, identificación del destino, partición ext4, espacio libre sin asignar y archivo tras remontar. Explica por qué el dispositivo puede aparecer en `lsblk` y no en `df`.

La ampliación de montaje al inicio usa el UUID real, copia de `/etc/fstab`, punto `/mnt/ud3-datos` y validación con `findmnt --verify` y `sudo mount -a` antes de reiniciar. El docente revisará la entrada; no se copia el UUID de otra persona. No hace falta modificar fstab para superar el procedimiento básico.

## P5. Redes virtuales y una web accesible

Duración orientativa: 180 minutos. Se usa Ubuntu instalado, Python 3 y dos rutas de acceso. Anota siempre desde qué ordenador abres el navegador: `127.0.0.1` representa a ese sistema concreto.

### 1. Comprueba el adaptador NAT

Con Ubuntu apagado, selecciona su VM → **Configuración → Red → Adaptador 1**. Comprueba **Habilitar adaptador**, **Conectado a: NAT** y, en opciones avanzadas si procede, **Cable conectado**. Guarda con **Aceptar** y arranca.

Dentro de Ubuntu abre una terminal con **Ctrl + Alt + T**. Ejecuta `ip -br address`, `ip route` y `getent hosts ubuntu.com`. Distingue interfaz, dirección, ruta por defecto y resolución. Abre Firefox desde el dock o **Mostrar aplicaciones → Firefox** y visita la web indicada en la teoría. Un ping aislado no es una prueba suficiente del servicio HTTPS.

### 2. Crea la red solo anfitrión

1. Apaga Ubuntu. Vuelve al administrador de VirtualBox: no busques este gestor dentro del invitado.
2. Abre **Archivo → Herramientas → Administrador de red**, o la herramienta global **Red** que muestre tu versión. En la pestaña **Redes solo anfitrión / Host-only Networks**, pulsa **Crear**. Windows puede solicitar autorización para crear un adaptador virtual; en el aula lo gestiona el docente.
3. Selecciona la red creada y abre **Propiedades**. En el adaptador utiliza la dirección y máscara aprobadas; el ejemplo es `192.168.56.1` y `255.255.255.0`.
4. En la pestaña **Servidor DHCP**, elige con el docente una de dos rutas: DHCP con rango documentado, o asignación estática sin un servidor que pueda repartir las mismas direcciones. Para este ejemplo estático no debe haber solapamiento con `.10` y `.11`.
5. Guarda. Antes de usar la subred, comprueba que no colisiona con una VPN u otra red del puesto. Si el rango es distinto, sustituye todas las direcciones del ejercicio de manera coherente.

### 3. Conecta el segundo adaptador a Ubuntu

Selecciona la VM → **Configuración → Red → Adaptador 2**. Marca **Habilitar adaptador** y elige **Adaptador solo anfitrión** o equivalente en **Conectado a**. En **Nombre**, selecciona la red creada. No cambies el Adaptador 1, que mantiene la salida NAT.

Arranca Ubuntu y consulta `ip -br address`. Localiza el nuevo adaptador contrastando la MAC de VirtualBox con la interfaz del invitado. No supongas que se llama siempre `enp0s8`.

### 4. Configura IPv4 en el escritorio Ubuntu

Abre el menú de estado superior derecho → **Configuración** → **Red**. Localiza la conexión cableada del segundo adaptador y pulsa su **engranaje**. En **IPv4**, elige **Manual**. Escribe dirección `192.168.56.10` y máscara `255.255.255.0` o prefijo `24`, según el campo. Deja vacía la puerta de enlace de esta conexión y no añadas DNS innecesario. La salida seguirá por NAT.

Pulsa **Aplicar**. Si no se actualiza el perfil, desactiva y activa esa conexión desde su interruptor. Ejecuta otra vez `ip -br address` e `ip route`. Debes ver la red de laboratorio y una ruta por defecto asociada a NAT. Si configuraste por error otra puerta de enlace, corrige ese perfil antes de continuar.

### 5. Crea y prueba el servidor web

Abre una terminal del Ubuntu invitado y ejecuta una orden cada vez:

```bash
mkdir -p ~/ud3-web
cd ~/ud3-web
printf '<h1>Web del laboratorio UD3</h1>\n' > index.html
python3 -m http.server 8000 --bind 0.0.0.0
```

La última orden mantiene el proceso activo: que no vuelva a aparecer el prompt no significa que se haya bloqueado. Abre el navegador **dentro de Ubuntu** y visita `http://127.0.0.1:8000`. Después abre el navegador **del anfitrión** y visita `http://192.168.56.10:8000`, usando la IP real si es distinta. Mira la terminal del servidor: debe registrar las peticiones recibidas.

Pulsa **Ctrl + C** en la terminal del servidor y recarga la página del anfitrión. Ahora el proceso no escucha. Explica por qué la IP puede seguir bien configurada aunque la web falle. Vuelve a ejecutar el servidor para recuperar el servicio.

### 6. Prueba una segunda ruta con reenvío NAT

Apaga Ubuntu. En **Configuración → Red → Adaptador 2** desmarca temporalmente su habilitación. Abre **Adaptador 1**, que sigue en NAT, despliega **Avanzadas** y pulsa **Reenvío de puertos**. Añade una regla con el botón **+**:

| Campo | Valor del ejercicio | Significado |
| --- | --- | --- |
| Nombre | web-ud3 | Etiqueta de la regla |
| Protocolo | TCP | Transporte utilizado por HTTP |
| IP anfitrión | 127.0.0.1 | Acceso desde el propio anfitrión |
| Puerto anfitrión | 8080 | Puerto que abrirá su navegador |
| IP invitado | IP NAT real, si es necesaria | Destino dentro de esa VM |
| Puerto invitado | 8000 | Puerto del servidor Python |

No uses en la regla la dirección solo anfitrión del adaptador desactivado. Puedes dejar la IP del invitado sin fijar si la versión y configuración NAT lo permiten; si la escribes, compruébala y documenta su vigencia. Guarda ambos diálogos con **Aceptar**. Arranca, inicia el servidor desde `~/ud3-web` y abre `http://127.0.0.1:8080` **en el anfitrión**.

### 7. Diagnóstico y entrega

Si responde dentro de Ubuntu y falla desde fuera, comprueba dirección de escucha, IP utilizada, adaptador, regla y firewall. No desactives globalmente la protección: cualquier regla se limita a red y puerto necesarios. Si 8080 está ocupado en el anfitrión, acuerda otro puerto y cambia la URL correspondiente, sin cambiar por ello el puerto 8000 del servidor.

Entrega diagrama con IP y puertos reales, prueba por solo anfitrión, prueba por NAT y explicación del fallo al detener Python. Al terminar, detén el servidor y retira la regla si no la utilizarás para P9. La ampliación conecta un segundo invitado a la misma red con MAC e IP diferentes.

## P6. Actualizaciones y control de cambios

Duración orientativa: 120 minutos. Trabaja en Ubuntu instalado y conserva un punto de retorno. Una actualización es una operación que se debe comprobar después, no solo una barra de progreso.

### 1. Guarda el estado inicial

Abre **Archivos → Carpeta personal** y comprueba que puedes crear un archivo. En la terminal ejecuta `df -hT` y `uname -r`. Apaga Ubuntu. En el administrador de VirtualBox, selecciona la VM y cambia de **Detalles** a **Instantáneas** mediante su menú de herramientas o vista. Pulsa **Tomar**, escribe `P6-antes-actualizar` y añade fecha y estado observado. Arranca de nuevo.

### 2. Refresca información y lee la propuesta

Pulsa **Ctrl + Alt + T**. Ejecuta `sudo apt update`. Cuando pida la contraseña, escríbela y pulsa **Intro**: normalmente no aparecen puntos ni asteriscos. Es un comportamiento previsto, no una falta de respuesta.

Lee el resultado. Si hay errores de descarga o se usan índices antiguos, no concluyas que la consulta fue correcta. Comprueba conexión, reloj y repositorios. Después ejecuta `apt list --upgradable`. Anota dos paquetes con versión disponible, o registra que no hay actualizaciones si ese es el caso.

### 3. Actualiza y verifica tras reinicio

Ejecuta `sudo apt upgrade`. Antes de aceptar, identifica cuánto se descargará, qué se instalará y si hay dependencias nuevas. No añadas `-y`: queremos leer la propuesta. Cuando termine, revisa si solicita reinicio y utiliza **menú de estado → Apagar/Cerrar sesión → Reiniciar** cuando corresponda.

Vuelve a abrir la terminal y ejecuta `uname -r`. Puede mantenerse si no se actualizó el kernel. Compara una aplicación o paquete seleccionado antes y después; no inventes un cambio para que la tabla parezca completa.

### 4. Instala una herramienta y comprueba su uso

```bash
apt show tree
sudo apt install tree
tree --version
mkdir -p ~/ud3-arbol/proyecto/src
tree ~/ud3-arbol
```

`apt show` permite inspeccionar el paquete antes de instalarlo. `tree --version` comprueba que el programa responde y `tree` sobre una ruta propia demuestra un uso real. No necesitas aplicar `full-upgrade`, `purge` o `autoremove` para terminar.

### 5. Incidencia y entrega

Con la VM de pruebas, desconecta únicamente su cable virtual: menú de la VM **Dispositivos → Red → Conectar adaptador** si existe, o control de red equivalente. Ejecuta `apt update`, conserva el mensaje, reconecta y repite. No borres los archivos de bloqueo de APT si otra actualización está trabajando.

Entrega tabla antes/después, propuesta interpretada, reinicio cuando proceda y comprobación de tree. Añade una explicación de `update` frente a `upgrade` y por qué el número del kernel no cambia siempre.

## P7. Instantáneas: recuperar y delimitar la pérdida

Duración orientativa: 120 minutos. Usaremos archivos dentro del disco del invitado, no una carpeta compartida, para que la restauración tenga un alcance claro.

### 1. Prepara un estado que puedas reconocer

En Ubuntu pulsa **Ctrl + Alt + T** y ejecuta:

```bash
mkdir -p ~/ud3-recuperacion
printf 'ESTADO A\n' > ~/ud3-recuperacion/estado.txt
cat ~/ud3-recuperacion/estado.txt
```

Apaga desde Ubuntu. En VirtualBox comprueba **Apagada**. Selecciona esta VM, abre la vista **Instantáneas** y pulsa **Tomar**. Escribe `P7-A` y una descripción: «estado.txt contiene A; posterior.txt no existe». Confirma. Así defines un criterio que luego podrás verificar.

### 2. Introduce un cambio controlado

Arranca Ubuntu y ejecuta:

```bash
printf 'ESTADO B\n' > ~/ud3-recuperacion/estado.txt
printf 'Creado después de P7-A\n' > ~/ud3-recuperacion/posterior.txt
ls -l ~/ud3-recuperacion
cat ~/ud3-recuperacion/estado.txt
```

Guarda las capturas y notas que necesites fuera del estado que vas a restaurar: por ejemplo, mediante la carpeta de evidencias aprobada. Escribe antes del retorno qué esperas encontrar y qué esperas perder.

### 3. Restaura la instantánea correcta

Apaga Ubuntu. En el administrador selecciona la VM → **Instantáneas**. Haz clic en `P7-A`, no en el estado actual, y pulsa **Restaurar** o utiliza botón derecho → **Restaurar instantánea**. Lee el diálogo: puede ofrecer crear una instantánea del estado actual antes del retorno. Anota si conservas ese estado adicional y por qué.

No pulses **Eliminar** pensando que significa volver. Tampoco borres manualmente archivos de la carpeta `Snapshots`. Confirma la restauración elegida y arranca.

### 4. Comprueba y explica

Abre la terminal, lista la carpeta y lee estado.txt. Debe corresponder al estado A; posterior.txt no formaba parte de ese punto de retorno. Si el resultado difiere, comprueba nombre de la instantánea, ruta de archivos y si realmente trabajaste dentro del disco del invitado.

Crea después un estado C y explica cómo continúa el trabajo. Desde el administrador abre la carpeta de la VM para observar su ocupación, sin editar sus componentes. Una cadena de instantáneas puede crecer aunque sus nombres sugieran «fotos» pequeñas.

Entrega predicción, evidencias de A/B y resultado de restauración. Explica una avería que esta operación no cubre. El experimento opcional con una carpeta compartida se realiza solo en una carpeta vacía de prueba: los archivos externos no retroceden al restaurar el invitado.

## P8. Clonar, exportar e importar con comprobación

Duración orientativa: 150 minutos. Antes de comenzar, mide espacio libre para copia, paquete e importación. No borres el único original antes de probar otra copia.

### 1. Crea un clon completo

Apaga Ubuntu y comprueba su estado en VirtualBox. Si tiene conectado el disco de datos que no se necesita, retíralo desde **Configuración → Almacenamiento** sin borrar el archivo VDI. Selecciona el origen → botón derecho → **Clonar**. Si esa acción aparece en **Máquina** en tu versión, utiliza la misma función.

Escribe `UD3-Ubuntu-Clon-codigo` y selecciona **Clon completo**. En política de direcciones MAC elige generar nuevas direcciones para los adaptadores necesarios. Selecciona el estado que vas a clonar y registra qué se incluirá. Completa el asistente y espera a la creación del disco independiente.

### 2. Evita identidades repetidas

Antes de iniciar origen y clon simultáneamente, revisa **Configuración → Red → Avanzadas → Dirección MAC** en cada uno. Si hay IP fija, debe ser diferente en el clon. Puedes arrancarlo con red desconectada para ajustar la identidad sin conflicto.

Dentro del clon, abre **Configuración → Sistema → Acerca de**, o la sección **Acerca de** que incluya **Nombre del dispositivo**, y cambia su nombre si la interfaz lo permite. La alternativa de terminal acordada es `sudo hostnamectl set-hostname ud3-clon-codigo`. Reinicia y comprueba con `hostnamectl`. En la conexión de laboratorio modifica la IPv4 mediante el engranaje de **Red**, igual que en P5.

Crea `~/archivo-del-clon.txt` solamente en el clon. Apágalo, arranca el origen y comprueba que ese archivo no aparece allí. Esta prueba acredita independencia de escrituras, pero ambas VM pueden seguir dependiendo del mismo SSD físico.

### 3. Exporta el estado elegido

Apaga el origen. En el administrador abre **Archivo → Exportar servicio virtualizado** o **Exportar máquina/appliance**, según la traducción. Selecciona únicamente Ubuntu, pulsa **Siguiente** y elige archivo **OVA** en la ubicación indicada. Registra versión del hipervisor, firmware, RAM, CPU, discos, red y archivo testigo antes de exportar.

Revisa los datos del paquete y confirma. No añadas credenciales personales. Un paquete de intercambio no garantiza conservar historia de instantáneas, secretos de TPM o todas las funciones de una plataforma.

### 4. Importa y revisa antes de iniciar

Abre **Archivo → Importar servicio virtualizado**. Selecciona el OVA, pulsa **Siguiente** y revisa la configuración propuesta. Cambia el nombre a `UD3-Ubuntu-Importada-codigo`, ajusta recursos al puesto y revisa la política de MAC. Comprueba la carpeta de destino para no confundirla con el origen.

Pulsa **Importar** y espera. Con la máquina todavía apagada, comprueba firmware, controlador de disco y adaptador de red. Arranca y verifica usuario, versión, archivo testigo y una aplicación o servicio. Si no puedes guardar origen e importación a la vez, el docente puede proporcionar otro equipo para importar; no se sacrifica la única copia válida para hacer sitio.

### 5. Entrega y diagnóstico

Entrega comparación origen/clon/importación, nuevas identidades, estado elegido, tamaño del paquete y resultados de pruebas. **Incidencia:** dos invitados conservan la misma IP estática aunque sus MAC sean diferentes. Explica qué campo debes revisar y por qué generar MAC nuevas no cambió esa configuración del sistema.

## P9. Proyecto integrador: laboratorio de un equipo de desarrollo

Duración: 240 minutos. Teoría: toda la unidad. Producto: laboratorio verificable, memoria breve y defensa individual.

### Encargo

Una pequeña empresa necesita Windows para una herramienta de escritorio y Ubuntu para probar una página web. Debes preparar ambos sistemas, describir sus recursos, permitir al anfitrión acceder al servicio de Ubuntu y demostrar recuperación ante un cambio fallido. El equipo disponible lo determina el docente. No puedes prometer simultaneidad si tus medidas no la justifican.

### Requisitos verificables

1. Plan justificado con arquitectura, versiones, fuentes, derechos de uso, presupuesto de RAM/disco y decisión de ejecución simultánea o alterna.
2. Windows y Ubuntu arrancan desde sus discos, sin depender de la ISO. Sus nombres permiten distinguirlos.
3. Registro de particiones y sistemas de archivos, y explicación de una partición pequeña que no contiene documentos del usuario.
4. Ubuntu muestra una página propia de al menos diez líneas de HTML con nombre del proyecto y dos datos técnicos comprobables. El anfitrión la visita por solo anfitrión o reenvío NAT limitado a bucle local.
5. Actualización y aceptación documentadas con resultados reales. Cualquier pendiente material se declara y se cierra con el docente.
6. Instantánea anterior a un cambio, cambio observable y restauración demostrada. Los datos que deban conservarse tienen una copia fuera del estado restaurado.
7. Exportación e importación de Ubuntu probada, o restauración de una copia independiente aprobada si el puesto no tiene espacio para ambas a la vez.
8. Informe de una incidencia con síntoma, hipótesis, prueba, resultado y solución. Una reinstalación completa sin diagnóstico no es la primera respuesta.

### Organización de las cuatro horas

Primera hora: valida el plan y completa requisitos pendientes de las VM. Segunda hora: configura y comprueba la página. Tercera hora: realiza recuperación y transferencia. Cuarta hora: verifica, redacta y demuestra. Puedes reutilizar las máquinas de prácticas anteriores si acreditas su preparación; no hay que repetir instalaciones para acumular capturas.

### Entrega y defensa

Memoria recomendada de 6-10 páginas más anexos necesarios. Incluye tabla de aceptación con criterio, prueba, resultado y evidencia. Añade diagrama de red con IP y puertos reales. El docente puede pedir: retirar la ISO; localizar la raíz; explicar una ruta; detener el servidor y diagnosticar el fallo; predecir qué se perderá al restaurar. Cada integrante debe poder hacerlo individualmente.

La rúbrica valora planificación 15%, instalación y aceptación 25%, servicio y red 20%, recuperación/transferencia 25% y documentación/defensa 15%. La guía docente concreta niveles y recuperación. No hace falta diseñar una web visualmente compleja: aquí se evalúa la infraestructura que la ejecuta.

## P10. Aplicaciones Linux: APT, paquete DEB y Snap

Duración orientativa: 120 minutos. Esta práctica desarrolla los apartados de paquetes del material de referencia. Utiliza Ubuntu instalado, repositorios del centro y una instantánea anterior. No se añaden PPA o claves de terceros para practicar su escritura.

### 1. Consulta los orígenes sin cambiarlos

Abre una terminal del invitado con **Ctrl + Alt + T**. Ejecuta `ls /etc/apt/sources.list.d`. Busca archivos `.sources` y `.list`. Si existe `ubuntu.sources`, consúltalo con `cat /etc/apt/sources.list.d/ubuntu.sources`; si no existe, el docente identificará el archivo utilizado por esa imagen. No crees uno vacío para que coincida con el ejemplo.

Anota una URI, una suite y un componente realmente presentes. Explica `Types`, `URIs`, `Suites`, `Components` y `Signed-By` cuando aparezcan. Leer un archivo de configuración no equivale a habilitar otro origen.

### 2. Descarga un DEB desde el repositorio aprobado

Ejecuta `sudo apt update` y comprueba que no quedan errores sin resolver. Crea una carpeta específica:

```bash
mkdir -p ~/ud3-paquetes
cd ~/ud3-paquetes
apt show hello
apt download hello
ls -lh
```

El paquete `hello` es un programa pequeño de demostración. Si la imagen del aula no lo ofrece, el docente indicará un equivalente. `apt download` descarga el archivo, pero no lo instala. Copia su nombre real, que incluye versión y arquitectura. Si hay varias revisiones en la carpeta, identifica una; no instales un comodín que seleccione archivos diferentes por accidente.

### 3. Inspecciona e instala el archivo local

Consulta los metadatos con `dpkg-deb --info ./NOMBRE_REAL.deb`. Sustituye el marcador por el nombre exacto. Después ejecuta `sudo apt install ./NOMBRE_REAL.deb`. El prefijo `./` identifica un archivo local; no es el nombre de un paquete que se buscará solamente por su identificador.

Lee la propuesta y acepta bajo el procedimiento de aula. Ejecuta `hello` y consulta `dpkg-query -W hello`. En **Mostrar aplicaciones** puede no aparecer un icono: este programa se usa desde la terminal. Que no haya lanzador gráfico no demuestra que la instalación haya fallado.

### 4. Distingue el nombre del paquete y el nombre del archivo

Consulta `dpkg -l hello` y localiza estado, versión y arquitectura. Ejecuta `sudo apt remove hello` y lee qué va a retirar. Comprueba si `hello` sigue disponible. Explica por qué los comandos de eliminación reciben normalmente `hello`, no el nombre completo `hello_version_arquitectura.deb` del archivo descargado.

`purge` trata también la configuración de paquete, pero no garantiza borrar documentos personales. No ejecutes limpiezas generales. El archivo descargado puede seguir en `~/ud3-paquetes` aunque el programa ya no esté instalado: son objetos distintos.

### 5. Observa Snap sin duplicar instalaciones

Ejecuta `snap --version` y `snap list` si Snap está disponible en la imagen. Selecciona un programa que ya esté instalado y consulta `snap info NOMBRE_REAL_DEL_SNAP`, sustituyendo el marcador. Anota canal, editor y versión que puedas identificar. No instales otra copia de la misma aplicación por rutina y no elimines un snap del sistema para demostrar el comando.

Entrega una tabla: origen, herramienta, objeto que gestiona, instalación comprobada y desinstalación. Compara APT/DEB con Snap. Conserva la evidencia de que descargar el DEB y ejecutar la aplicación son dos pasos diferentes. Si Snap no está disponible, documenta esa situación y resuelve la comparación con la información docente.

## P11. Protección del sistema y restauración en Windows

Duración orientativa: 90 minutos. Se trabaja en un **clon de Windows de laboratorio** con instantánea previa, nunca en el puesto anfitrión. El docente prepara una aplicación de prueba e instalador oficial autorizados y un estado sin esa aplicación. Si se necesita clave de recuperación del cifrado de la VM, debe estar disponible antes de empezar.

### 1. Diferencia los dos niveles de retorno

Apaga el clon. En el administrador de VirtualBox abre **Instantáneas → Tomar** y crea `P11-antes-restauracion`. Este punto devuelve la VM completa al estado previsto si el experimento falla. Después arranca Windows: el punto de restauración que crearás ahora pertenece al propio sistema invitado y tiene un alcance diferente.

### 2. Abre Protección del sistema

Dentro de Windows invitado pulsa **Inicio**, escribe **Crear un punto de restauración** y abre el resultado de configuración del sistema. También puedes pulsar **Windows + R**, escribir `SystemPropertiesProtection` y aceptar.

En la pestaña **Protección del sistema**, selecciona la unidad del sistema, normalmente C:. Comprueba el estado de protección. Si está desactivada y el docente ha preparado el ejercicio, pulsa **Configurar → Activar protección del sistema**, asigna el límite de espacio acordado y pulsa **Aplicar → Aceptar**. No actives o desactives protección de unidades desconocidas.

### 3. Crea un punto identificable

Pulsa **Crear**, escribe `P11-antes-aplicacion` y espera al mensaje de finalización. Anota fecha y nombre exactos. Guarda un documento testigo en **Explorador → Documentos** con una frase. Recuerda: Restaurar sistema se dirige a archivos y configuración del sistema; no debe utilizarse como sustituto de una copia de documentos.

### 4. Introduce un cambio de aplicación controlado

Abre **Explorador → Descargas** y ejecuta únicamente el instalador oficial de prueba que ha indicado el docente. Lee cada pantalla y conserva la configuración acordada. Comprueba la aplicación mediante su función básica y consulta **Inicio → Configuración → Aplicaciones → Aplicaciones instaladas** para anotar el estado. No utilices software desconocido para provocar una avería.

### 5. Inspecciona qué restaurará Windows

Vuelve a **Protección del sistema** y pulsa **Restaurar sistema**. Otra ruta es **Windows + R → rstrui.exe**. Pulsa **Siguiente**, elige `P11-antes-aplicacion` y utiliza **Detectar programas afectados**. Anota qué indica, en lugar de suponer que cualquier archivo desaparecerá.

Si el punto no existe o el programa de prueba no queda dentro del alcance indicado, no prometas una reversión que no has comprobado. Registra el caso y reajusta el experimento con el docente. Conserva evidencias fuera de la VM si las necesitas después.

### 6. Restaura el clon y comprueba el resultado

Cierra aplicaciones y guarda el trabajo. En el clon preparado, revisa el resumen y confirma la restauración del punto elegido. Espera al reinicio sin interrumpirlo. Al volver, comprueba el mensaje de resultado, el estado de la aplicación, los programas afectados y el documento testigo. Explica la diferencia entre archivos personales y estado del sistema según lo observado.

Si la restauración falla, registra el mensaje y utiliza el punto de retorno completo de VirtualBox preparado al principio bajo supervisión. No repitas reparaciones sin leer el resultado. Entrega la comparación de ambos mecanismos, el punto creado, la lista de programas afectados y la comprobación posterior.

## X1. Ampliación: Windows y Ubuntu en arranque dual virtual

Duración adicional: 180 minutos. Se usa una VM nueva de 120 GiB compatible con Windows 11. Nunca se modifica el arranque del ordenador personal.

### 1. Instala Windows dejando un destino para Linux

Crea la VM desde **Nueva**, con los requisitos y configuración de P3. En la pantalla del instalador que permite elegir el destino, selecciona el espacio del VDI de 120 GiB y utiliza **Nuevo / Crear partición**, si esa revisión lo ofrece, para reservar unos 70 GiB para Windows y sus particiones auxiliares. Deja al menos 45 GiB sin asignar. Revisa los tamaños que realmente muestra el instalador antes de aceptar; la suma debe dejar espacio para ESP, MSR y recuperación.

Termina Windows y comprueba arranque y archivo testigo. Si se ha activado cifrado de dispositivo, confirma el procedimiento y la clave de recuperación de aula antes de continuar. Apaga y crea un clon completo o copia recuperable mediante el procedimiento de P8.

### 2. Instala Ubuntu en el espacio sin asignar

En **Configuración → Almacenamiento**, conecta la ISO Ubuntu a la unidad óptica. Arranca en el mismo modo UEFI. Sigue idioma, teclado y modalidad interactiva de P2. En configuración de disco selecciona **Instalación manual**; no uses **Borrar disco**.

En la tabla localiza el espacio libre reservado. Selecciónalo y usa **+ / Añadir** para crear la raíz Linux en ext4, con punto de montaje `/`. Identifica la ESP existente por su función y formato FAT32. Reutilízala como `/boot/efi` sin marcar formateo. No uses para Linux la partición NTFS de Windows.

### 3. Revisa el resumen y prueba los dos sistemas

Antes de instalar, escribe qué partición se formateará y cuáles se conservarán. Si el resumen incluye borrar o formatear Windows o ESP, cancela y corrige. Termina, retira ISO y prueba ambos sistemas.

Si no aparece un menú combinado, abre las entradas de arranque del firmware virtual: en muchas VM UEFI se accede con **Esc** al comienzo, pero depende de versión y tiempo de arranque. Sigue la ayuda de esa VM y localiza sus entradas de Windows y Ubuntu. La ausencia de un menú GRUB visible no prueba que Windows se haya borrado.

Entrega mapa final, testigo conservado en Windows y evidencia de arranque de cada sistema. Explica por qué solo uno se ejecuta cada vez, a diferencia de dos invitados separados.

## X2. Ampliación: una web en contenedor dentro de Ubuntu

Duración adicional: 120 minutos, con Docker Engine preparado y probado por el docente. Se trabaja en un clon Ubuntu. No se instala Docker Desktop dentro de la VM para este ejercicio ni se mezclan paquetes de diferentes procedimientos.

### 1. Abre la terminal del sistema que ejecuta el motor

Arranca Ubuntu y pulsa **Ctrl + Alt + T**. Comprueba `uname -r`, `sudo docker version` y `sudo docker info`. Si no responde el motor, registra el error y resuelve el servicio con el docente. No continúes suponiendo que cualquier error se arregla añadiendo usuarios al grupo docker.

### 2. Crea el volumen y el servidor

Ejecuta una orden cada vez. Las barras invertidas permiten continuar la misma orden en la línea siguiente; no añadas texto después de ellas.

```bash
sudo docker volume create ud3_webdatos
sudo docker run -d --name ud3-web \
  -p 127.0.0.1:8081:80 \
  -v ud3_webdatos:/usr/share/nginx/html \
  nginx:stable-alpine
sudo docker ps
```

`--name` identifica el contenedor, `-d` lo deja en segundo plano y `-p` publica el puerto. El volumen se monta en el directorio de páginas de nginx. La imagen se descarga si no estaba disponible; eso requiere conexión al registro.

Abre **Firefox dentro de Ubuntu**, escribe `http://127.0.0.1:8081` en su barra y pulsa **Intro**. El bucle local pertenece aquí a la VM Ubuntu. Si usas el navegador del anfitrión físico, esa misma dirección designará otro sistema.

### 3. Cambia la página y observa persistencia

```bash
sudo docker exec ud3-web sh -c \
  'printf "<h1>Datos persistentes UD3</h1>\n" > /usr/share/nginx/html/index.html'
sudo docker exec ud3-web uname -r
sudo docker image inspect nginx:stable-alpine --format '{{json .RepoDigests}}'
```

Vuelve a Firefox y pulsa **Ctrl + R**. Comprueba tu página. Compara el kernel con el del primer paso y registra el digest de imagen: una etiqueta como `stable-alpine` puede apuntar a otro contenido en el futuro.

### 4. Recrea el contenedor sin borrar el volumen

```bash
sudo docker stop ud3-web
sudo docker rm ud3-web
```

Repite la orden `docker run` del apartado 2 con el mismo nombre de volumen. Recarga el navegador y comprueba que sigue tu página. Consulta `sudo docker volume ls` y `sudo docker ps -a` para distinguir los recursos. El volumen conserva datos entre instancias, pero no es automáticamente una copia independiente.

Entrega salida del motor, kernel comparado, digest y página tras recreación. Cuando termine la evaluación, limpia únicamente los recursos de este ejercicio siguiendo la indicación del docente; no ejecutes una limpieza global del motor.

## Entrega y comprobación común

Cada práctica se entrega con su código, versiones, estado inicial, decisiones, resultados e incidencias. Las capturas llevan pie explicativo. No se mezclan en la misma entrega las respuestas de otra actividad salvo indicación docente.

## Rúbrica común de prácticas

| Criterio | Puntos |
| --- | ---: |
| Preparación y destino identificados | 2 |
| Procedimiento y resultado funcional | 3 |
| Comprobaciones y diagnóstico | 3 |
| Evidencias explicadas y entrega | 2 |
