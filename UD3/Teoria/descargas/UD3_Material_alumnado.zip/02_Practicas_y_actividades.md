# Unidad 3. Cuaderno de prácticas y actividades

Sistemas Informáticos · 1.º de DAM · Laboratorio del alumnado

## Normas de trabajo y entrega

Trabaja únicamente con las máquinas virtuales y los discos de prueba identificados en cada ficha. No conectes discos físicos directamente al invitado. Los cambios de particiones se limitan a discos virtuales vacíos o clones de laboratorio. Las contraseñas y claves de activación no se incorporan a capturas ni entregas.

Antes de empezar una práctica: lee la teoría indicada, dibuja el estado inicial y escribe una predicción. Durante el trabajo: registra decisiones y errores, sin ocultar intentos fallidos. Al terminar: ejecuta las pruebas de aceptación y explica si los resultados confirman la predicción.

Las capturas deben mostrar un dato legible, estar numeradas y llevar un pie explicativo. Para identificar la autoría, utiliza nombre de máquina y un código de alumno de aula; no es necesario exponer datos personales. Los vídeos del catálogo 03 se consultan en el momento indicado y se acompañan de preguntas. La documentación escrita prevalece si el vídeo utiliza una interfaz antigua o simplifica un concepto.

Carpeta de entrega por práctica: Pxx_codigo. Incluye informe.pdf, evidencias y, cuando se pida, archivos de texto de configuración. No entregues ISO ni discos virtuales de decenas de gigabytes en la plataforma salvo indicación docente. La demostración práctica del equipo sirve para evaluar el funcionamiento.

## P0. Auditoría del puesto e ISO verificada

Duración: 90 minutos. Teoría: B1 y B3. Trabajo individual con contraste por parejas. Producto: ficha de viabilidad y registro de descarga.

### Qué vas a aprender

Comprobar si un equipo puede alojar el laboratorio y demostrar que una imagen coincide con la huella oficial de su revisión. El resultado debe permitir que otra persona entienda por qué has elegido una configuración y de dónde procede el instalador.

### Preparación

Necesitas acceso de lectura a la información del anfitrión y una carpeta de trabajo. No cambies su firmware. Si la virtualización está deshabilitada o se requiere instalar software, comunica la incidencia al docente, que coordinará el puesto del centro. Una descarga puede prepararse antes de clase.

### Procedimiento

1. Registra sistema anfitrión, arquitectura, CPU, núcleos/hilos, RAM total, RAM disponible aproximada y espacio libre en la unidad del laboratorio. En Windows puedes usar Administrador de tareas e Información del sistema. Distingue almacenamiento y memoria.
2. Comprueba si el sistema informa de virtualización habilitada. Anota la herramienta y el dato observado. Si no puedes comprobarlo, marca «pendiente» y explica cómo lo resolverá el docente.
3. Consulta requisitos oficiales de Windows 11 y del Ubuntu elegido. Separa requisitos oficiales de la configuración propuesta para clase.
4. Diseña una tabla con reserva del anfitrión, VM Ubuntu, VM Windows y margen. Indica si se ejecutarán simultáneamente. En 8 GiB, plantea ejecución alterna y un puesto compatible para las tareas que lo necesiten.
5. Accede a la descarga oficial de Ubuntu. Registra edición, versión completa, arquitectura, URL, fecha, tamaño y nombre del archivo. El docente puede proporcionar la ISO desde un repositorio del centro conservando la trazabilidad.
6. Obtén la referencia SHA-256 correspondiente a ese archivo. No uses la huella de otra revisión. Guarda la URL del listado oficial.
7. Calcula la huella con Get-FileHash o sha256sum, como se muestra en B3. Compara todos los caracteres. Adjunta huella calculada y esperada como texto seleccionable.
8. Escribe una conclusión: «Coincide con la referencia ...» o «No coincide; no se autoriza su uso». Explica qué has comprobado y qué requeriría verificar autenticidad mediante firma.

### Comprobación e incidencia

El docente entrega dos cadenas de ejemplo, idénticas salvo un carácter central. Compara las cadenas sin limitarte al principio y al final. Si tu propia descarga no coincide, comprueba primero nombre y revisión; no la uses hasta resolverlo. No es necesario descargar una ISO corrupta para practicar la incidencia.

Aceptación: arquitectura adecuada, presupuesto razonado, ISO identificada sin ambigüedad y huella completa cotejada. Evidencias: tabla del equipo, tabla de presupuesto, salida del hash y referencia. Preguntas: ¿por qué una ISO de 6 GiB no cabe como archivo en FAT32?, ¿por qué un hash obtenido de un foro no demuestra por sí solo autenticidad?

Ampliación: sigue la guía oficial de firma de Ubuntu, identifica la huella de la clave y explica qué significa una firma válida y qué significa una clave aún no confiable localmente.

## P1. Crear y entender la máquina virtual

Duración: 120 minutos. Teoría: B2 y B6. Vídeo: V1; V2 como apoyo. Producto: VM Ubuntu vacía y ficha técnica.

### Preparación y predicción

VirtualBox debe estar instalado o lo instalará el docente desde la fuente oficial con la versión estable acordada. Las prácticas básicas no necesitan Extension Pack. Predice qué ocurrirá al iniciar una máquina con disco vacío y sin ISO.

### Procedimiento

1. Anota la versión de VirtualBox. Localiza la carpeta por defecto de máquinas y escoge una ubicación local del aula con espacio suficiente.
2. Crea UD3-Ubuntu-codigo. Selecciona el tipo Linux y la versión Ubuntu de 64 bits compatible. No conectes todavía la ISO. Evita la instalación desatendida para esta primera práctica.
3. Asigna inicialmente 2 vCPU y 4 GiB de RAM si el presupuesto de P0 lo permite. Justifica cualquier ajuste. Mantén recursos libres para el anfitrión.
4. Crea un disco VDI dinámico de 50 GiB. Explica qué capacidad verá el invitado y cuánto puede ocupar inicialmente el archivo real.
5. Selecciona firmware UEFI para mantener el itinerario de referencia. Registra controlador de almacenamiento, adaptador de pantalla y modo de red NAT. Si tu versión presenta otros nombres, identifica su función.
6. Inicia sin ISO. Registra el mensaje o la pantalla de firmware. Apaga mediante el control de la VM; todavía no hay sistema instalado que cerrar.
7. Con la VM apagada, conecta la ISO verificada a la unidad óptica virtual. Comprueba que se ve el archivo correcto y no un disco de otra máquina.
8. Arranca hasta el menú o entorno inicial de Ubuntu. No instales todavía. Identifica la diferencia entre el archivo ISO y el archivo VDI.
9. Apaga y consulta la carpeta de la VM desde el anfitrión. Identifica configuración, disco y registros. No edites ni elimines sus archivos.

### Pruebas y razonamiento

Aceptación: la VM aparece en el gestor, posee el hardware acordado, no arranca un sistema de disco vacío y sí puede iniciar el medio verificado. Entrega ficha de CPU, RAM, firmware, VDI, red, ruta de la carpeta y versión del hipervisor; añade dos capturas de configuración y la comparación de arranques.

Incidencia controlada: con la VM apagada, desconecta la ISO y repite el arranque. Diagnostica utilizando «medio disponible» y «disco instalado». Después restituye la ISO. Preguntas: ¿crear un VDI instala Ubuntu?, ¿por qué la tarjeta de red del invitado puede aparecer como cableada si el anfitrión usa Wi-Fi?, ¿qué problema puede causar asignar toda la RAM del anfitrión?

## P2. Ubuntu Desktop: de la ISO al sistema instalado

Duración: 180 minutos. Teoría: B4 y B7. Vídeo V3. Producto: Ubuntu instalado con pruebas de aceptación.

### Estado inicial

VM P1 con un único VDI vacío de 50 GiB, ISO verificada, NAT y configuración registrada. No hay otros discos conectados. Identifica el tamaño del disco antes de confirmar cualquier operación de borrado.

### Procedimiento

1. Arranca la ISO y entra en el entorno de prueba. Localiza el instalador. Anota una característica que permita reconocer la sesión Live.
2. Elige instalación interactiva. Configura idioma y prueba el teclado escribiendo símbolos, arroba y caracteres habituales. Ajusta accesibilidad si la necesitas.
3. Comprueba la conexión del invitado. Para esta práctica no es necesario activar puente ni conectarlo como otro equipo de la red del centro.
4. Elige la selección de aplicaciones acordada. Si se ofrecen descargas durante la instalación, decide según la conexión del aula y anótalo. Si se aplazan, se realizarán en P6.
5. Selecciona instalación automática usando todo el disco virtual vacío. Antes de aceptar, comprueba que el resumen afecta al único VDI de 50 GiB. Explica por qué este paso destruiría datos si el destino ya contuviera información.
6. Configura un nombre de equipo identificable y un usuario de aula. Usa una contraseña adecuada; no la incluyas en el informe. Selecciona Europe/Madrid.
7. Anota dos decisiones del resumen final y confirma. Espera sin interrumpir el proceso. Registra cualquier error con texto, momento y operación en curso.
8. Tras la instalación, sigue la indicación para retirar el medio. Si es necesario, apaga y retira la ISO desde el almacenamiento de VirtualBox. Arranca desde el disco.
9. Crea ~/comprobacion-ud3.txt con el código de alumno y una frase explicativa. Reinicia desde Ubuntu y verifica que permanece.
10. Ejecuta los comandos de comprobación de B7. Para cada uno, extrae un dato y explícalo: distribución, kernel, nombre, hora, memoria, particiones, dirección y ruta.

### Integración con el anfitrión

Comprueba si la resolución se adapta al tamaño de ventana. Si el centro pide Guest Additions, sigue una sola ruta aprobada. Ruta con ISO de complementos: actualiza índices, instala build-essential, dkms y las cabeceras que correspondan al kernel en ejecución; utiliza Dispositivos → Insertar imagen de CD de Guest Additions; ejecuta su instalador desde la ruta de montaje real y revisa el registro. No inventes una ruta /media común a todos los equipos.

Si Secure Boot impide cargar módulos, detén esa parte y registra el diagnóstico para que el docente siga el procedimiento de firma o la ruta de paquetes del centro. No cambies ajustes de seguridad del anfitrión. Tras instalar, reinicia y prueba la función de integración. La instalación básica sigue siendo evaluable aunque la integración quede pendiente por compatibilidad documentada.

### Aceptación, evidencias e incidencia

Aceptación: arranque sin ISO, usuario correcto, archivo persistente, versión y recursos coherentes, particiones montadas y reloj razonable. Evidencias: resumen previo al borrado, arranque desde disco y tabla de resultados de los comandos. Incluye incidencias y solución; no hace falta capturar cada pantalla del asistente.

Incidencia: vuelve a conectar la ISO con la VM apagada y observa el menú inicial. Comprueba el orden de arranque, explica por qué reaparece el instalador y vuelve a dejar el arranque desde disco. No reinstales.

Preguntas: ¿qué diferencia hay entre uname -r y /etc/os-release?, ¿qué perderías si hubieras trabajado solamente en modo Live?, ¿qué dispositivo físico real contiene finalmente tu archivo de prueba?

## P3. Windows 11 con instalación y licencia diferenciadas

Duración: 180 minutos. Teoría: B8. Apoyo: guía ilustrada del año pasado y fuentes F2/F3. Producto: Windows con informe de aceptación.

### Preparación

Se necesita medio oficial, edición y derecho de uso acordados por el centro. El docente prepara el método de cuenta compatible con esa edición. No se exige una cuenta personal del alumno ni se distribuyen claves en documentos. Comprueba recursos del anfitrión antes de encender también Ubuntu.

### Procedimiento

1. Crea UD3-Windows-codigo con su propio VDI dinámico de 80 GiB, 2 vCPU y 4-6 GiB de RAM según viabilidad. Selecciona la plantilla de Windows 11 y registra opciones de firmware, TPM 2.0 virtual y arranque seguro.
2. Conecta la ISO y desactiva el modo desatendido si lo propone el asistente. Arranca el instalador de forma interactiva.
3. Verifica idioma y teclado. Identifica edición. Introduce una clave únicamente por el procedimiento del centro; si el instalador permite aplazarla y el docente lo ha previsto, registra que la activación sigue siendo una comprobación pendiente.
4. Selecciona instalación limpia o personalizada según lo que muestre la versión. En el disco virtual vacío, permite crear automáticamente las particiones. Documenta el destino antes de confirmar.
5. Completa copia y reinicios. Si vuelve a pedir arrancar desde el medio, deja que continúe desde disco. No empieces otra instalación por confundir ese aviso.
6. Completa región, red y cuenta de aula según la preparación docente. No utilices guías de omisión de requisitos ni comandos antiguos para eludir el asistente.
7. Retira la ISO y comprueba arranque. Crea un archivo en Documentos, reinicia y verifica persistencia.
8. Abre winver, msinfo32, tpm.msc, Administración de discos y Administrador de dispositivos. Completa una tabla con versión, modo de firmware, estado observado de arranque seguro, TPM, particiones y dispositivos con incidencia.
9. Consulta activación sin exponer claves. Completa Windows Update y los reinicios necesarios dentro de la ventana de clase. Si quedan descargas, anota el estado exacto para continuar.
10. Si el docente pide integración, instala Guest Additions dentro de Windows, revisa el instalador y reinicia. Comprueba resolución y dispositivo gráfico.

### Aceptación e incidencia

Aceptación: arranque sin ISO, persistencia, particiones interpretadas, requisitos acreditados y actualización completada o pendiente claramente delimitada para el cierre docente. Un error de requisitos no se resuelve ocultándolo: se revisa firmware, TPM, RAM, CPU y compatibilidad del anfitrión.

Incidencia de análisis: el docente entrega una ficha ficticia con 2 GiB de RAM, sin TPM virtual y firmware heredado. Explica por qué no cumple y qué cambios habría que comprobar antes de instalar. No modifiques la VM ya instalada para producir el fallo.

Entrega: ficha técnica, mapa de particiones con función de ESP/MSR/sistema/recuperación si aparecen, estado de dispositivos y actualizaciones, y explicación de instalación frente a activación. Pregunta: ¿por qué una partición sin letra puede ser esencial?

## P4. Particionar y montar un disco de datos

Duración: 150 minutos. Teoría: B4 y B5. Producto: disco de datos con GPT, ext4 y archivo persistente.

### Control del destino

Se usa la VM Ubuntu instalada. Apágala y crea un punto de retorno o un clon antes de empezar. Añade un VDI nuevo de 8 GiB con nombre UD3-DATOS-codigo. No se particiona el disco de 50 GiB del sistema. Predice qué herramientas verán un disco nuevo todavía sin formato.

### Procedimiento gráfico

1. Con Ubuntu apagado, conecta el VDI de 8 GiB al controlador de almacenamiento. Arranca y ejecuta lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS.
2. Identifica el disco por tamaño y ausencia de montajes. El disco que contiene / queda excluido. Anota su nombre real; no supongas /dev/sdb.
3. Abre Discos o GParted, según la imagen del centro. Si falta la herramienta elegida, consulta con el docente; su instalación se hace desde repositorios aprobados.
4. Selecciona el disco de 8 GiB. Antes de crear tabla, contrasta nombre y tamaño con lsblk. Si hay duda, detente en ese punto y solicita verificación del destino.
5. Crea tabla GPT. Después crea una partición de aproximadamente 4 GiB en ext4, con etiqueta UD3_DATOS. Deja el espacio restante sin asignar para distinguir «disco», «partición» y «volumen». No marques opciones de borrado seguro del disco.
6. Monta desde la herramienta gráfica o el explorador. Consulta findmnt y anota el punto de montaje real. Comprueba si tu usuario tiene escritura. Si no la tiene, ajusta únicamente el propietario del directorio raíz de ese volumen montado, verificando antes el punto exacto con findmnt. No cambies permisos de todo /media ni del sistema.
7. Crea un archivo llamado prueba-persistencia.txt con tres líneas. Desmonta mediante la herramienta, vuelve a montar y verifica el contenido. No desconectes el disco mientras esté montado.
8. Compara lsblk, findmnt y df -hT. Explica por qué los 8 GiB del disco no se convierten en 8 GiB de sistema de archivos montado si solamente has particionado la mitad.
9. Apaga, comprueba el VDI conectado y arranca. Si no se monta automáticamente al inicio, móntalo desde la interfaz y comprueba el archivo. Distingue persistencia de datos y montaje automático.

### Ampliación de montaje persistente

Solo después de superar el procedimiento básico: obtén el UUID real con lsblk -f; crea /mnt/ud3-datos; guarda copia de /etc/fstab; añade una entrada del volumen ext4 con UUID real y opciones apropiadas para un disco de laboratorio no esencial, como defaults,nofail. No copies UUID de otro alumno. Desmonta el montaje anterior, valida la sintaxis con findmnt --verify y prueba sudo mount -a antes de reiniciar. Revisa el resultado y los permisos. Una entrada incorrecta se corrige recuperando la copia, sin reiniciar a ciegas.

### Evidencias y preguntas

Aceptación: sistema original intacto, GPT en el disco secundario, partición ext4, espacio no asignado visible y archivo recuperable tras desmontar/montar. Entrega dos mapas antes/después, nombre y tamaño del destino, tabla de sistemas de archivos y una explicación de los comandos. Incidencia de análisis: «Aparece en lsblk pero no en df». Propón dos causas y cómo distinguirlas.

Pregunta final: si falla el SSD del anfitrión, ¿te protege que el archivo esté en otro VDI guardado en ese mismo SSD?

## P5. Redes virtuales y una web accesible

Duración: 180 minutos. Teoría: B9. Vídeo V5. Producto: mapa de red y pruebas HTTP por dos rutas.

### Preparación

VM Ubuntu con python3 disponible. Usa únicamente la red del laboratorio. En esta práctica no hace falta puente. Predice desde qué sistema será accesible 127.0.0.1 en cada prueba.

### Fase A · NAT y diagnóstico

1. Arranca con un adaptador NAT. Registra ip -br address e ip route. Identifica interfaz, IP y puerta de enlace.
2. Comprueba resolución con getent hosts ubuntu.com y conexión con el navegador a https://ubuntu.com. Si curl ya está instalado puedes usar curl -I https://ubuntu.com. Distingue resolución y respuesta del servicio.
3. Desconecta el «cable» del adaptador desde VirtualBox, observa el fallo y recoge el estado de la interfaz. Reconecta y comprueba recuperación. No alteres la tarjeta física del anfitrión.

### Fase B · Solo anfitrión

4. Apaga Ubuntu. En el gestor de red de VirtualBox crea o identifica una red solo anfitrión. Documenta IP y máscara del adaptador del anfitrión. El ejemplo usa 192.168.56.1/24, pero debes adaptarlo si hay solapamiento.
5. Decide con el docente: DHCP de esa red con direcciones asignadas automáticamente, o direcciones estáticas sin solapar el rango DHCP. Si trabajas con estáticas 192.168.56.10/24 y .11/24, evita que DHCP las reparta.
6. Añade un segundo adaptador a Ubuntu conectado a esa red. Mantén el primero en NAT para salida. Arranca y localiza ambas interfaces por su MAC y configuración; no supongas un nombre fijo como enp0s8.
7. Configura el segundo adaptador con la IP de aula mediante la interfaz de Ubuntu. En la red solo anfitrión no añadas una segunda puerta de enlace por defecto ni DNS innecesario. Consulta ip route para comprobarlo.
8. Crea ~/ud3-web e index.html siguiendo B9, con un mensaje que incluya el código de tu máquina. Ejecuta python3 -m http.server 8000 --bind 0.0.0.0 desde esa carpeta. Mantén la terminal abierta.
9. En Ubuntu visita http://127.0.0.1:8000. Desde el anfitrión visita http://IP_REAL_DE_UBUNTU:8000. Sustituye el texto por la IP del segundo adaptador. Registra el acceso que aparece en la terminal del servidor.
10. Detén el servidor con Ctrl+C y repite desde el anfitrión. Explica por qué una IP correcta no garantiza que haya un servicio escuchando.

### Fase C · NAT con reenvío

11. Apaga la VM y desactiva temporalmente el segundo adaptador. En el NAT del primero crea la regla TCP: IP anfitrión 127.0.0.1, puerto anfitrión 8080, puerto invitado 8000. Si pide IP invitado, usa la IP NAT actual de esa VM y revisa que no cambie. No vincules la regla a todas las interfaces del equipo.
12. Arranca y ejecuta de nuevo el servidor dentro de Ubuntu. Desde el anfitrión abre http://127.0.0.1:8080. Si el puerto está ocupado, elige otro y documenta ambos extremos.
13. Explica el recorrido navegador anfitrión → 127.0.0.1:8080 → regla NAT → invitado:8000. Borra o deshabilita la regla al terminar si no será necesaria para el proyecto.

### Aceptación e incidencia

Aceptación: salida NAT comprobada, acceso por solo anfitrión y acceso mediante reenvío, con las IP/puertos reales y sin puente. Entrega diagrama, tabla de interfaces y tres pruebas con explicación.

Incidencia: el servidor responde dentro de Ubuntu, pero no desde el anfitrión. Comprueba primero si escucha en 127.0.0.1 en lugar de 0.0.0.0; después interfaz elegida, IP, regla, puerto y firewall. Si el firewall está activo, utiliza una regla limitada a la red y puerto necesarios y documenta su retirada. No lo desactives globalmente.

Ampliación: conecta un clon Ubuntu a la misma red solo anfitrión y prueba acceso entre invitados. Evita IP repetida y MAC duplicada. Después explica la diferencia con Red NAT y con Red interna.

## P6. Actualizaciones y control de cambios

Duración: 120 minutos. Teoría: B10. Producto: registro antes/después y Ubuntu actualizado.

### Procedimiento

1. Comprueba espacio en anfitrión e invitado. Crea una instantánea apagada llamada P6-antes-actualizar y anota su alcance.
2. Arranca Ubuntu. Registra distribución, kernel y hora. Ejecuta sudo apt update y lee si todos los repositorios se consultan correctamente.
3. Consulta apt list --upgradable. Selecciona dos paquetes propuestos, si los hay, y anota versión anterior/candidata. Si no hay actualizaciones, registra ese resultado válido.
4. Ejecuta sudo apt upgrade. Antes de confirmar, lee paquetes nuevos, actualizaciones, descarga y espacio adicional. No utilices -y en esta práctica. Anota si el gestor propone algún conflicto.
5. Comprueba si se solicita reinicio y realízalo si corresponde. Vuelve a registrar uname -r; el kernel puede mantenerse si no se actualizó.
6. Consulta apt show tree; instala con sudo apt install tree. Ejecuta tree --version y utilízalo sobre una carpeta de prueba de tres niveles que tú hayas creado.
7. Consulta apt show antes de elegir otra aplicación. Explica qué información ayuda a decidir si es el paquete correcto.
8. Compara estado inicial y final. No ejecutes full-upgrade, autoremove o purge por rutina: explica qué revisarías antes de usarlos.

### Incidencia y aceptación

Incidencia controlada: desconecta el cable virtual, ejecuta apt update, registra el error de red y reconecta. Repite y compara. No interpretes «se usan índices anteriores» como una actualización de metadatos correcta.

Aceptación: metadatos consultados sin fallos de red sin resolver, actualización revisada, reinicio cuando proceda y aplicación comprobada. Entrega registro con comandos, resultados, decisiones y reversión disponible. Preguntas: ¿update instala nuevas versiones?, ¿upgrade puede añadir dependencias?, ¿por qué no se debe borrar un bloqueo de APT sin saber qué proceso lo mantiene?

## P7. Instantáneas: recuperar y delimitar la pérdida

Duración: 120 minutos. Teoría: B11. Vídeo V4. Producto: experimento documentado de retorno a un estado anterior.

### Procedimiento

1. Dentro de Ubuntu crea ~/ud3-recuperacion/estado.txt con «ESTADO A». Apaga ordenadamente. En VirtualBox toma instantánea P7-A y describe el estado esperado.
2. Arranca, modifica el contenido a «ESTADO B» y crea posterior.txt. Comprueba ambos. Guarda fuera de la VM las capturas o notas que necesitas para demostrar este estado.
3. Predice qué existirá al regresar a P7-A. Apaga. Selecciona la instantánea correcta y la acción restaurar; lee si se ofrece conservar el estado actual en otra instantánea y registra tu elección.
4. Arranca. Comprueba que estado.txt vuelve al estado A y posterior.txt no forma parte del estado restaurado. Si el resultado difiere, revisa qué instantánea seleccionaste y dónde se guardaron realmente los archivos.
5. Crea ESTADO C y explica cómo continúa el trabajo desde el estado restaurado. No elimines archivos de instantáneas desde el explorador del anfitrión.
6. Anota el espacio que ocupa la carpeta de la VM. Explica por qué sucesivas instantáneas pueden aumentar el consumo y por qué no se deben conservar indefinidamente sin una política.

### Experimento opcional de alcance externo

Con una carpeta compartida de prueba expresamente preparada por el docente, crea un archivo en el anfitrión después de la instantánea. Restaura y observa que el archivo externo no retrocede. No utilices Documentos personales ni carpetas compartidas con información real.

Aceptación: predicción, estados A/B observables, restauración y explicación de pérdida posterior. Preguntas: ¿borrar una instantánea equivale a restaurarla?, ¿qué ocurre si falla el disco físico donde están base y diferenciales?, ¿por qué guardamos evidencias fuera antes de restaurar?

## P8. Clonar, exportar e importar con comprobación

Duración: 150 minutos. Teoría: B6 y B11. Vídeo V6. Producto: clon completo e importación comprobada.

### Preparación

Calcula espacio antes de empezar. Apaga Ubuntu y retira ISO y discos secundarios innecesarios desde configuración, sin borrar archivos. El volumen de datos de P4 se conserva desconectado para evitar confundir la prueba. No exportes credenciales personales. Revisa la instantánea o estado actual que utilizarás.

### Procedimiento

1. Crea un clon completo llamado UD3-Ubuntu-Clon-codigo. Selecciona la opción para generar nuevas MAC y clonar el estado elegido. Escribe qué diferencia habría con un clon enlazado.
2. Antes de encender origen y clon a la vez, comprueba IP estáticas, MAC y nombre. Inicialmente arranca el clon con red desconectada si necesitas modificar su identidad sin conflicto.
3. Cambia el nombre del clon desde la herramienta de sistema acordada. Si conserva una IP estática, asígnale otra del rango de laboratorio. Comprueba el nombre y conectividad al reiniciar.
4. Crea solo en el clon ~/archivo-del-clon.txt. Apaga. Arranca el origen y comprueba que no aparece allí. Explica qué independencia demuestra y qué riesgo físico sigue compartiendo.
5. Apaga el origen y expórtalo a OVA en la ubicación indicada por el docente. Registra tamaño, tiempo aproximado y configuración importante en una ficha externa. No asumas que el paquete conserva la historia de instantáneas ni todos los dispositivos específicos.
6. Importa como UD3-Ubuntu-Importada-codigo, con nuevas MAC. Si el espacio escasea, el docente puede hacer la importación en otro equipo; no borres el único original para liberar espacio antes de probar el respaldo.
7. Antes de arrancar, revisa RAM, firmware, controladores y red. Comprueba arranque, versión, archivo testigo y un servicio o aplicación utilizada en clase.
8. Registra diferencias respecto al origen. Si la importación necesita ajustes, anótalos para que la transferencia sea reproducible.

### Aceptación e incidencia

Aceptación: clon independiente a nivel de archivos, identidad revisada e importación que arranca y conserva el archivo testigo. Una exportación completada sin probar no supera por sí sola la práctica.

Incidencia de análisis: «El clon no obtiene red y tiene la misma IP fija que el origen». Formula diagnóstico y corrección. Pregunta: ¿un OVA guardado en el mismo SSD protege frente a la avería de ese SSD? Diseña destino alternativo y prueba de restauración.

## P9. Proyecto integrador: laboratorio de un equipo de desarrollo

Duración: 240 minutos. Teoría: toda la unidad. Producto: laboratorio verificable, memoria breve y defensa individual.

### Encargo

Una pequeña empresa necesita Windows para una herramienta de escritorio y Ubuntu para probar una página web. Debes preparar ambos sistemas, describir sus recursos, permitir al anfitrión acceder al servicio de Ubuntu y demostrar recuperación ante un cambio fallido. El equipo disponible lo determina el docente. No puedes prometer simultaneidad si tus medidas no la justifican.

### Requisitos verificables

1. Plan justificado con arquitectura, versiones, fuentes, derechos de uso, presupuesto de RAM/disco y decisión de ejecución simultánea o alterna.
2. Windows y Ubuntu arrancan desde sus discos, sin depender de la ISO. Sus nombres permiten distinguirlos.
3. Registro de particiones y sistemas de archivos, y explicación de una partición pequeña que no contiene documentos del usuario.
4. Ubuntu muestra una página propia de al menos diez líneas de HTML con nombre del proyecto y dos datos técnicos comprobables. El anfitrión la visita por solo anfitrión o reenvío NAT limitado a bucle local.
5. Actualización y aceptación documentadas con resultados reales. Cualquier pendiente material se declara y se cierra con el docente.
6. Instantánea anterior a un cambio, cambio observable y restauración demostrada. Los datos que deban conservarse tienen una copia fuera del estado restaurado.
7. Exportación e importación de Ubuntu probada, o restauración de una copia independiente aprobada si el puesto no tiene espacio para ambas a la vez.
8. Informe de una incidencia con síntoma, hipótesis, prueba, resultado y solución. Una reinstalación completa sin diagnóstico no es la primera respuesta.

### Organización de las cuatro horas

Primera hora: valida el plan y completa requisitos pendientes de las VM. Segunda hora: configura y comprueba la página. Tercera hora: realiza recuperación y transferencia. Cuarta hora: verifica, redacta y demuestra. Puedes reutilizar las máquinas de prácticas anteriores si acreditas su preparación; no hay que repetir instalaciones para acumular capturas.

### Entrega y defensa

Memoria recomendada de 6-10 páginas más anexos necesarios. Incluye tabla de aceptación con criterio, prueba, resultado y evidencia. Añade diagrama de red con IP y puertos reales. El docente puede pedir: retirar la ISO; localizar la raíz; explicar una ruta; detener el servidor y diagnosticar el fallo; predecir qué se perderá al restaurar. Cada integrante debe poder hacerlo individualmente.

La rúbrica valora planificación 15%, instalación y aceptación 25%, servicio y red 20%, recuperación/transferencia 25% y documentación/defensa 15%. La guía docente concreta niveles y recuperación. No hace falta diseñar una web visualmente compleja: aquí se evalúa la infraestructura que la ejecuta.

## X1. Ampliación: Windows y Ubuntu en arranque dual virtual

Duración adicional: 180 minutos. Se realiza después del itinerario básico, en una VM nueva de 120 GiB. No se modifica el arranque del ordenador personal.

1. Prepara VM compatible con Windows 11, UEFI y sus requisitos de seguridad. Instala Windows en una partición de aproximadamente 70 GiB y deja al menos 45 GiB sin asignar. Permite que el instalador cree sus particiones auxiliares. Verifica el espacio real en el resumen antes de confirmar.
2. Completa aceptación de Windows y apaga. Si se ha activado cifrado de dispositivo, verifica que tienes el procedimiento y clave de recuperación de aula antes de continuar. No cifres con una cuenta personal una imagen compartida.
3. Haz una copia o clon completo recuperable de esta VM. Arranca Ubuntu desde ISO en el mismo modo UEFI.
4. Selecciona instalación manual en el espacio sin asignar. Crea raíz ext4 con el espacio suficiente. Reutiliza la ESP existente como /boot/efi sin formatearla. No selecciones «borrar disco» ni modifiques la partición de Windows.
5. Revisa el resumen: solo se formatea la nueva raíz Linux. Si el instalador no permite identificar claramente el destino, vuelve atrás y consulta la configuración, en lugar de aceptar por intuición.
6. Instala, retira ISO y prueba arranque de Ubuntu y Windows. Si no hay menú GRUB visible, utiliza el gestor UEFI de la VM para localizar las entradas. No borres ni reinstales Windows por esa ausencia.
7. Desde ambos sistemas comprueba que un archivo testigo de Windows permanece y que Ubuntu utiliza su propia raíz. Dibuja el mapa final.

Aceptación: ambos sistemas arrancan, Windows conserva testigo y particiones esenciales, Ubuntu usa su raíz y la ESP se conserva. Entrega secuencia de decisiones y diferencia entre arranque dual y dos VM simultáneas.

## X2. Ampliación: una web en contenedor dentro de Ubuntu

Duración adicional: 120 minutos, con motor Docker preparado por el docente. Teoría: B12. Vídeo V7. Producto: contenedor recreado con volumen persistente.

### Preparación docente necesaria

En una VM clonada para esta ampliación se instala Docker Engine con un único procedimiento aprobado. Se registra origen y versión del paquete. Si se utiliza la distribución oficial de Docker, seguir F11 y no mezclarla con docker.io. Debe estar activo el servicio y funcionar sudo docker run --rm hello-world. Este paso requiere conexión y descargas; se prepara con antelación. No se instala Docker Desktop dentro de la VM para este ejercicio.

### Experimento del alumno

1. Registra uname -r dentro de Ubuntu y predice si el contenedor tendrá otro kernel. Comprueba sudo docker version y sudo docker info.
2. Crea el volumen con sudo docker volume create ud3_webdatos.
3. Ejecuta la web:

```bash
sudo docker run -d --name ud3-web \
  -p 127.0.0.1:8081:80 \
  -v ud3_webdatos:/usr/share/nginx/html \
  nginx:stable-alpine
```

4. En el navegador de Ubuntu abre http://127.0.0.1:8081. La primera ejecución descarga la imagen si no está presente. Guarda la salida de sudo docker image inspect nginx:stable-alpine --format '{{json .RepoDigests}}' para registrar el contenido utilizado; una etiqueta por sí sola puede cambiar.
5. Modifica la página del volumen:

```bash
sudo docker exec ud3-web sh -c \
  'printf "<h1>Datos persistentes UD3</h1>\n" > /usr/share/nginx/html/index.html'
```

6. Recarga el navegador y registra el resultado. Consulta sudo docker exec ud3-web uname -r y compáralo con el kernel de Ubuntu. No confundas las herramientas del contenedor con un nuevo kernel arrancado.
7. Detén y elimina únicamente ese contenedor:

```bash
sudo docker stop ud3-web
sudo docker rm ud3-web
```

8. Ejecuta otra vez el comando del paso 3 con el mismo volumen. Comprueba que aparece tu página modificada. Explica por qué eliminar el contenedor no ha eliminado el volumen.
9. Consulta sudo docker ps -a y sudo docker volume ls. Limpia solamente los recursos del ejercicio cuando el docente haya evaluado; no ejecutes limpiezas globales.

Aceptación: respuesta HTTP dentro de Ubuntu, digest registrado, kernel comparado y datos presentes tras recreación. Preguntas: ¿por qué 127.0.0.1:8081 en el navegador del anfitrión físico no apunta al mismo sitio?, ¿un volumen persistente es automáticamente una copia independiente?, ¿qué necesitarías para recrear la práctica sin depender de una etiqueta mutable?

## Banco de actividades de consolidación

### A12 · Diagnóstico escrito

Para cada caso, entrega síntoma, dos hipótesis, primera prueba de lectura y acción justificada. No propongas formatear como primera medida.

1. La VM muestra firmware y no encuentra medio de arranque.
2. Ubuntu inicia, pero el escritorio no cambia de resolución.
3. El invitado accede por dirección IP a un servicio, pero falla por nombre.
4. La VM indica espacio libre, pero el anfitrión tiene el SSD lleno.
5. El archivo posterior a una instantánea desaparece al restaurar.
6. Dos clones tienen conectividad intermitente en la misma red.
7. Tras instalar, reaparece siempre el menú de la ISO.
8. apt update utiliza índices antiguos tras varios avisos de descarga.

### A13 · Decisiones profesionales

Elabora un presupuesto para un laboratorio con anfitrión de 16 GiB y SSD con 220 GiB libres. Debe incluir Ubuntu, Windows, un clon, una exportación y margen para crecimiento. Distingue tamaño lógico máximo y ocupación actual. No supongas que los discos dinámicos permanecerán siempre pequeños.

### A14 · Explicar a otra persona

Graba, si el docente lo autoriza, una demostración de 3-5 minutos o realiza una explicación presencial equivalente. Elige: recorrido de una petición web hacia la VM; diferencia entre instantánea y copia; o instalación comprobada frente a escritorio Live. Incluye una predicción y una verificación. No publiques credenciales ni grabes a terceros.

### A15 · Autoevaluación de salida

Responde sin apuntes y comprueba después con la teoría: ¿qué instala una ISO?, ¿qué almacena un VDI?, ¿qué partición usa FAT32 para el arranque UEFI?, ¿por qué update no actualiza programas?, ¿qué depende de un clon enlazado?, ¿qué recupera una instantánea y qué efectos externos no revierte?, ¿qué significan anfitrión e invitado?, ¿qué prueba acredita que un respaldo sirve?

## Plantilla breve de informe

Identificación: práctica, código, fecha, versiones y equipo. Objetivo: qué se pretende demostrar. Estado inicial: recursos y punto de retorno. Predicción: resultado esperado y razón. Procedimiento: decisiones y comandos relevantes. Resultados: criterio, prueba, resultado y evidencia. Incidencias: síntoma, hipótesis, prueba, corrección y nueva comprobación. Conclusión: qué has demostrado, qué queda pendiente y por qué. Fuentes: enlaces concretos y fecha de consulta.
