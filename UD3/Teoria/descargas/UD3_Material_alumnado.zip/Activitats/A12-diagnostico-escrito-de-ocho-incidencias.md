# Actividad 3.12 · Diagnóstico escrito de ocho incidencias

<div class="lesson-banner" markdown>
<div class="lesson-number">3.12</div>
<div markdown>
**Actividad escrita · Diagnóstico escrito de ocho incidencias**

Razonar, interpretar y justificar antes de ejecutar.
</div>
</div>

<div class="activity-meta" markdown>
<span>30 min</span><span>Individual</span><span>10 puntos</span><span>Aules</span>
</div>

**Código: A12.** Actividad escrita con entrega propia.

**Teoría relacionada:** [Índice de teoría](../index.md#teoria-por-bloques)

[Descargar actividad en PDF](descargas/Actividad_3_12_Apellidos_Nombre.pdf){ .md-button .md-button--primary }
[Original editable en texto](descargas/Actividad_3_12_Apellidos_Nombre.txt){ .md-button download }

Tiempo orientativo: 30 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

## Antes de responder

Consulta la teoría relacionada antes de responder. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

## Caso de trabajo

Resuelve ocho fichas: VM sin medio de arranque; escritorio que no adapta resolución; servicio accesible por IP y no por nombre; invitado con espacio y SSD lleno; archivo posterior perdido tras restaurar; clones con conectividad intermitente; menú ISO que reaparece; y apt update con avisos e índices anteriores.

## Cuestiones

1. Para cada ficha escribe el síntoma sin inventar datos no aportados.
2. Plantea dos hipótesis diferenciadas y selecciona la primera prueba de lectura.
3. Explica qué resultado apoyaría cada hipótesis.
4. Propón una corrección limitada al problema y una prueba de cierre. No utilices formatear como respuesta inicial.

## Entrega de esta actividad

Ocho filas de diagnóstico con síntoma, hipótesis, prueba y cierre. No hay que provocar todas las averías en una máquina real. Guarda el archivo como `Actividad_3_12_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

## Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |
