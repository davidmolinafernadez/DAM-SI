# Actividad 3.7 · Elegir una red virtual para cada encargo

<div class="lesson-banner" markdown>
<div class="lesson-number">3.7</div>
<div markdown>
**Actividad escrita · Elegir una red virtual para cada encargo**

Razonar, interpretar y justificar antes de ejecutar.
</div>
</div>

<div class="activity-meta" markdown>
<span>25 min</span><span>Individual</span><span>10 puntos</span><span>Aules</span>
</div>

**Código: A7.** Actividad escrita con entrega conjunta con P6; procede de la antigua UD4/A9.

**Teoría relacionada:** [Teoría 3.6: Redes virtuales y servicio web](../06-preparar-redes-virtuales.md)


Tiempo orientativo: 25 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

[Descargar actividad 3.7 en PDF](descargas/Actividad_3_7_Apellidos_Nombre.pdf){ .md-button }

[Original editable](descargas/Actividad_3_7_Apellidos_Nombre.txt){ .md-button download }

## Antes de responder

Consulta la teoría relacionada antes de responder. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

## Caso de trabajo

Debes atender cuatro encargos: actualizar una VM; comunicar dos invitados sin anfitrión ni exterior; acceder desde el anfitrión a una web del invitado; y probar una web desde otros puestos de la LAN del aula.

## Cuestiones

1. Elige un modo de red para cada caso y razona el alcance de la comunicación.
2. Distingue NAT individual de Red NAT. Indica qué conclusión errónea surgiría al tratarlos como iguales.
3. Dibuja anfitrión:8080 → regla → invitado:8000 y explica quién inicia la conexión.
4. Explica por qué 127.0.0.1 puede designar sistemas distintos al escribirlo en navegadores diferentes.
5. Identifica el caso que necesita autorización de red del centro y qué comprobarías del firewall.

## Entrega de esta actividad

Tabla de escenarios y diagrama de petición. No se activa puente ni se cambian adaptadores en esta actividad. Guarda el archivo como `UD3_A7_Codigo.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

## Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## Aplicación y entrega conjunta

Tras razonar los casos, realiza [P6 · Redes virtuales y web](../practicas/P6-redes-virtuales.md). Adjunta sus evidencias como anexo al mismo `UD3_A7_Codigo.pdf`. Los 25 minutos escritos se integran en las 6 h de actividades seleccionando apartados de A6, sin añadir tiempo ni duplicar entregas. La rúbrica es formativa; no crea por sí sola una nueva ponderación en el cuaderno.
