# Unidad 3. Cuaderno de actividades escritas

Sistemas Informáticos · 1.º DAM

Estas actividades se resuelven por escrito, mediante esquemas, comparación, interpretación y diagnóstico. No son las guías de ejecución de las VM. Cada una se entrega en su propio archivo, con el nombre indicado por el docente. Las prácticas tienen páginas y cuaderno diferentes.

Los tiempos son orientativos. El profesorado selecciona actividades para las horas previstas y utiliza el resto como refuerzo o ampliación; no hay que sumar obligatoriamente todo el banco a una sola sesión.

## A1 · Decidir antes de instalar

Tiempo orientativo: 20 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B1. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Un estudio utiliza una aplicación exclusiva de Windows y quiere aprender administración Linux. Dispone de un portátil x86-64 con 8 GiB de RAM y 90 GiB libres. El propietario necesita conservar sus documentos y seguir trabajando durante el curso.

### Cuestiones

1. Compara instalación física, arranque dual y máquina virtual según simultaneidad, recursos, reinicios y efecto sobre los datos.
2. Elige dos alternativas viables y explica qué condición comprobarías antes de recomendarlas.
3. Diseña una tabla de RAM para anfitrión, invitado y margen. No confundas capacidad total con memoria disponible.
4. Redacta una recomendación de 200 palabras que incluya limitaciones y una prueba posterior de aceptación.

### Entrega de esta actividad

Tabla de alternativas y recomendación razonada. No se instala ningún sistema ni se modifica el disco. Guarda el archivo como `Actividad_3_1_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A2 · El recorrido de un archivo en una VM

Tiempo orientativo: 20 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B2. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Una persona guarda index.html dentro de Ubuntu virtualizado. El disco de Ubuntu indica 18 GiB libres; al mismo tiempo, el SSD del anfitrión se está llenando. El VDI es dinámico y hay una instantánea anterior.

### Cuestiones

1. Dibuja el recorrido archivo → sistema de archivos invitado → partición → disco virtual y diferenciales → archivo anfitrión → SSD.
2. Explica en qué nivel se mide cada espacio libre y por qué pueden ser diferentes.
3. Indica qué comprobarías primero si una escritura falla aunque Ubuntu muestre espacio.
4. Relaciona anfitrión, invitado e hipervisor con los recursos que aparecen en el dibujo.

### Entrega de esta actividad

Esquema comentado y respuesta al caso. No se debe llenar realmente el disco para comprobarlo. Guarda el archivo como `Actividad_3_2_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A3 · Integridad y autenticidad de una ISO

Tiempo orientativo: 20 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B3. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

El equipo A descarga ISO y hash desde un foro. El equipo B obtiene la imagen desde un espejo, comprueba la firma del listado oficial de hashes y contrasta la identidad de la clave. Ambos dicen: «Mi archivo es auténtico porque dos cadenas coinciden».

### Cuestiones

1. Distingue archivo descargado, hash esperado, hash calculado y firma.
2. Explica qué ha probado cada equipo y qué confianza falta en el caso del foro.
3. Describe qué ocurriría si se usase el hash de otra revisión con el mismo nombre comercial.
4. Diseña una ficha de verificación con fuente, versión, arquitectura, nombre exacto y conclusión.

### Entrega de esta actividad

Análisis comparado y ficha vacía de verificación. Calcular la huella de tu ISO se hace en P0, no en esta actividad. Guarda el archivo como `Actividad_3_3_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A4 · Diseñar el arranque y las particiones

Tiempo orientativo: 25 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B4. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Debes proponer un disco Linux UEFI de 60 GiB. Se quiere separar /home para facilitar futuras reinstalaciones y conservar un registro de qué se formateará. Todavía no se ha abierto ningún instalador.

### Cuestiones

1. Dibuja tabla, particiones, tamaños aproximados, formatos y puntos de montaje.
2. Identifica la ESP y explica por qué no se trata como otra partición de documentos.
3. Compara tu diseño con uno de una sola raíz y razona una ventaja y un límite de separar /home.
4. Explica qué se perdería si se marca formatear /home durante una reinstalación.
5. Corrige las frases «GPT siempre exige UEFI» y «una partición de datos ya es una copia de seguridad».

### Entrega de esta actividad

Plano de disco y justificación de decisiones. No se crean particiones ni se realizan formatos. Guarda el archivo como `Actividad_3_4_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A5 · Elegir un sistema de archivos

Tiempo orientativo: 20 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B5. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Hay cuatro destinos: raíz de Ubuntu, sistema de Windows, partición EFI y memoria de intercambio que guardará vídeos de 8 GiB. Debes justificar el formato según la función de cada destino.

### Cuestiones

1. Elige entre ext4, NTFS, FAT32 y exFAT para los cuatro destinos. Explica si hay condiciones de compatibilidad que comprobar.
2. Razona por qué tener 20 GiB libres no garantiza poder copiar un archivo de 8 GiB en cualquier formato.
3. Explica diferencia entre volumen, sistema de archivos y punto de montaje.
4. Un disco aparece en lsblk y no en df. Propón dos situaciones que lo expliquen sin concluir que la herramienta falla.

### Entrega de esta actividad

Tabla de decisiones y explicación de los dos listados. No hace falta instalar una herramienta de particionado. Guarda el archivo como `Actividad_3_5_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A6 · Prever el crecimiento de discos virtuales

Tiempo orientativo: 20 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B6. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Un ordenador tiene 100 GiB libres. Dos VDI dinámicos tienen capacidad lógica de 80 GiB cada uno, pero hoy ocupan 20 GiB cada uno. Se quieren conservar varios puntos de retorno y exportar una máquina.

### Cuestiones

1. Separa capacidad lógica máxima, ocupación actual y espacio físico restante.
2. Explica por qué los discos dinámicos no garantizan que el laboratorio siempre quepa.
3. Incluye en tu previsión exportación, importación e instantáneas. Declara qué tamaños son estimaciones.
4. Propón una política de revisión y un umbral de aviso razonado, sin presentarlo como regla universal.
5. Explica por qué no se deben borrar manualmente los discos diferenciales para liberar espacio.

### Entrega de esta actividad

Presupuesto de almacenamiento y política de vigilancia. No se crean archivos grandes para agotar el SSD. Guarda el archivo como `Actividad_3_6_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A7 · Detectar una falsa instalación

Tiempo orientativo: 20 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B7. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Un compañero ve el escritorio Ubuntu, crea un documento y concluye que ya está instalado. Al apagar y retirar la ISO aparece un mensaje de medio no arrancable. Conservas una ficha que dice «VDI nuevo y vacío».

### Cuestiones

1. Propón dos hipótesis coherentes y una comprobación para cada una.
2. Explica qué diferencia hay entre el escritorio Live y el sistema del disco.
3. Diseña una secuencia de tres pruebas que acrediten arranque independiente y persistencia.
4. Indica por qué una captura del escritorio no permite resolver por sí sola el caso.
5. Escribe una respuesta técnica al compañero que evite reinstalar antes de diagnosticar.

### Entrega de esta actividad

Ficha de diagnóstico y lista de aceptación. Las pruebas reales del invitado se ejecutan en P2. Guarda el archivo como `Actividad_3_7_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A8 · Aceptar una instalación de Windows

Tiempo orientativo: 20 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B8. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Windows llega al escritorio. Administrador de dispositivos muestra un dispositivo desconocido, Windows Update pide reiniciar y Activación indica un estado pendiente. El informe solo contiene una captura del fondo de pantalla.

### Cuestiones

1. Identifica los tres asuntos pendientes y qué información falta para resolver cada uno.
2. Asocia winver, msinfo32, tpm.msc, diskmgmt.msc y devmgmt.msc con el dato que permiten comprobar.
3. Redacta una incidencia con estado, hipótesis, acción y criterio de cierre.
4. Explica instalación, activación y derecho de uso sin dar por hecho que omitir clave crea una evaluación.
5. Decide qué evidencia pedirías antes de entregar ese puesto como terminado.

### Entrega de esta actividad

Informe de aceptación y tabla de herramientas. No hace falta instalar Windows para resolver este caso escrito. Guarda el archivo como `Actividad_3_8_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A9 · Elegir una red virtual para cada encargo

Tiempo orientativo: 25 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B9. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Debes atender cuatro encargos: actualizar una VM; comunicar dos invitados sin anfitrión ni exterior; acceder desde el anfitrión a una web del invitado; y probar una web desde otros puestos de la LAN del aula.

### Cuestiones

1. Elige un modo de red para cada caso y razona el alcance de la comunicación.
2. Distingue NAT individual de Red NAT. Indica qué conclusión errónea surgiría al tratarlos como iguales.
3. Dibuja anfitrión:8080 → regla → invitado:8000 y explica quién inicia la conexión.
4. Explica por qué 127.0.0.1 puede designar sistemas distintos al escribirlo en navegadores diferentes.
5. Identifica el caso que necesita autorización de red del centro y qué comprobarías del firewall.

### Entrega de esta actividad

Tabla de escenarios y diagrama de petición. No se activa puente ni se cambian adaptadores en esta actividad. Guarda el archivo como `Actividad_3_9_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A10 · Escoger una estrategia de recuperación

Tiempo orientativo: 20 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B11. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

La empresa quiere deshacer una prueba fallida, llevar una VM a otro equipo, protegerse de la avería de un SSD y ahorrar espacio al distribuir una base de aula. Una misma operación no cubre automáticamente las cuatro necesidades.

### Cuestiones

1. Asocia cada necesidad con instantánea, clon completo, clon enlazado, exportación o respaldo independiente.
2. Explica qué dependencias hay en un clon enlazado.
3. Describe qué cambios posteriores se perderían al restaurar una instantánea y qué efectos externos seguirían existiendo.
4. Propón una prueba de importación/restauración que permita aceptar la copia.
5. Explica por qué un clon completo en el mismo SSD no resuelve por sí solo la avería física.

### Entrega de esta actividad

Matriz de necesidades y protocolo de comprobación. No se restaura ni elimina ninguna VM. Guarda el archivo como `Actividad_3_10_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A11 · Máquina virtual o contenedor

Tiempo orientativo: 20 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B12. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Un desarrollador afirma: «He descargado una imagen Ubuntu en Docker, así que he instalado otra VM con un kernel Ubuntu independiente». También guarda datos importantes solamente dentro de la capa escribible del contenedor.

### Cuestiones

1. Identifica las dos confusiones en la primera afirmación y corrígela.
2. Dibuja hardware, anfitrión, VM Ubuntu y contenedores del laboratorio X2. Señala dónde está el kernel.
3. Distingue imagen, contenedor y volumen con un ejemplo de servicio web.
4. Predice qué ocurre al detener, volver a iniciar y eliminar un contenedor.
5. Justifica cuándo elegirías VM completa y cuándo contenedor para un trabajo de DAM.

### Entrega de esta actividad

Diagrama de capas y tabla de ciclo de vida. Los comandos Docker y la recreación real pertenecen a X2. Guarda el archivo como `Actividad_3_11_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A12 · Diagnóstico escrito de ocho incidencias

Tiempo orientativo: 30 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B4, B6, B7, B9, B10, B11. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Resuelve ocho fichas: VM sin medio de arranque; escritorio que no adapta resolución; servicio accesible por IP y no por nombre; invitado con espacio y SSD lleno; archivo posterior perdido tras restaurar; clones con conectividad intermitente; menú ISO que reaparece; y apt update con avisos e índices anteriores.

### Cuestiones

1. Para cada ficha escribe el síntoma sin inventar datos no aportados.
2. Plantea dos hipótesis diferenciadas y selecciona la primera prueba de lectura.
3. Explica qué resultado apoyaría cada hipótesis.
4. Propón una corrección limitada al problema y una prueba de cierre. No utilices formatear como respuesta inicial.

### Entrega de esta actividad

Ocho filas de diagnóstico con síntoma, hipótesis, prueba y cierre. No hay que provocar todas las averías en una máquina real. Guarda el archivo como `Actividad_3_12_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A13 · Presupuesto profesional de laboratorio

Tiempo orientativo: 25 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B1, B6, B11. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Dispones de un anfitrión de 16 GiB y 220 GiB libres en su unidad de trabajo. Debes prever Ubuntu, Windows, un disco de datos, un clon y una exportación con importación de comprobación. La carga de aplicaciones todavía puede variar.

### Cuestiones

1. Diseña un presupuesto de RAM que incluya anfitrión y margen y declara si propones simultaneidad.
2. Diseña otro de disco que distinga capacidad lógica, ocupación estimada y crecimiento.
3. Señala qué medida real falta antes de aceptar que todo cabe.
4. Propón qué trasladarías a otro destino si la importación no cabe, manteniendo una copia válida.
5. Redacta una condición de aceptación que el cliente pueda comprobar sin saber VirtualBox.

### Entrega de esta actividad

Dos tablas, supuestos y decisión final. No se pide crear ni exportar máquinas en esta actividad. Guarda el archivo como `Actividad_3_13_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A14 · Explicar un mecanismo con evidencia

Tiempo orientativo: 25 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B2, B9, B11. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Debes explicar a otra persona uno de estos mecanismos: recorrido de una petición web, instantánea frente a respaldo independiente, o Live frente a instalación persistente. Puede ser una explicación presencial o una grabación autorizada de 3-5 minutos.

### Cuestiones

1. Prepara un guion con una pregunta inicial y una predicción.
2. Dibuja las capas, rutas o estados implicados sin saltarte el nivel del anfitrión.
3. Selecciona una evidencia ya obtenida en una práctica y explica qué demuestra.
4. Termina con una limitación o caso que tu evidencia no acredita.
5. Revisa que no aparezcan credenciales, terceros sin permiso ni datos personales innecesarios.

### Entrega de esta actividad

Guion, esquema y exposición presencial o grabación autorizada. No se exige publicar el vídeo ni mostrar el rostro. Guarda el archivo como `Actividad_3_14_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A15 · Autoevaluación razonada de salida

Tiempo orientativo: 20 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B1, B2, B3, B4, B5, B6, B7, B8, B9, B10, B11, B12. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Comprueba qué conceptos puedes explicar sin tener abierto el asistente. Responde primero sin apuntes; después contrasta con la teoría y conserva tus correcciones con otra marca o color.

### Cuestiones

1. Distingue ISO, VDI, ESP, raíz y /home.
2. Explica anfitrión, invitado e hipervisor y un límite del aislamiento.
3. Relaciona IP, ruta, DNS y servicio con una prueba de cada nivel.
4. Distingue apt update de apt upgrade y explica cuándo puede no cambiar el kernel.
5. Explica instantánea, clon enlazado y copia independiente; di cómo validarías un respaldo.
6. Indica una idea que aún necesites comprobar y la página de teoría que consultarás.

### Entrega de esta actividad

Respuestas iniciales, correcciones y plan de repaso. No se califica acumular capturas. Guarda el archivo como `Actividad_3_15_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A16 · Leer una actualización antes de aceptarla

Tiempo orientativo: 20 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B10. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Una propuesta de actualización anuncia 18 paquetes actualizados, 2 nuevos y 0 eliminados. Una compañera cree que eso demuestra que se ha ejecutado full-upgrade. Otra ejecuta update con la red caída y afirma que todos los programas ya están al día.

### Cuestiones

1. Explica qué puedes y qué no puedes deducir de los números de la propuesta.
2. Distingue refrescar índices, actualizar paquetes y cambiar de versión de distribución.
3. Razona si la instalación de dependencias nuevas es compatible con apt upgrade.
4. Indica qué mensaje buscarías para detectar que se han usado índices antiguos.
5. Diseña una tabla antes/después con versión, propuesta, reinicio y prueba de funcionamiento.

### Entrega de esta actividad

Análisis de las dos afirmaciones y plantilla de control de cambios. No se realizan actualizaciones reales: se harán en P6. Guarda el archivo como `Actividad_3_16_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A17 · Identificar paquetes y repositorios

Tiempo orientativo: 25 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B10. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Tienes un archivo programa_1.4_amd64.deb, un programa instalado con APT y una aplicación que aparece en snap list. Además, una guía antigua propone renombrar una clave descargada y añadir un PPA sin comprobar la versión de Ubuntu.

### Cuestiones

1. Distingue archivo descargado, nombre de paquete e instalación disponible.
2. Asocia dpkg-deb --info, dpkg-query -W, apt install ./archivo.deb y snap list con la información o acción correspondiente.
3. Explica los campos Types, URIs, Suites, Components y Signed-By de una definición .sources.
4. Indica qué revisarías antes de añadir un origen externo y por qué cambiar la extensión no convierte el formato de una clave.
5. Compara retirar una aplicación y eliminar sus documentos personales.

### Entrega de esta actividad

Mapa de herramientas y revisión de la propuesta de repositorio. No se añade ningún origen ni se importa ninguna clave. Guarda el archivo como `Actividad_3_17_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A18 · Punto de restauración o instantánea de VM

Tiempo orientativo: 25 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B11. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Un usuario ha borrado un documento; otro instaló un programa que altera el sistema; un tercero perdió el SSD donde tenía VM e instantáneas. Todos quieren pulsar «Restaurar sistema» para resolverlo.

### Cuestiones

1. Identifica qué información falta en cada caso y qué mecanismo podría ayudar.
2. Explica alcance de un punto de Windows, instantánea de VirtualBox y copia independiente de documentos.
3. Justifica por qué hay que revisar protección activada, punto disponible y programas afectados antes de prometer una reversión.
4. Compara Timeshift con una copia de la carpeta personal sin afirmar que incluyen siempre los mismos datos.
5. Diseña una evidencia antes/después que no se pierda con el propio retorno.

### Entrega de esta actividad

Tabla de fallos, mecanismos y límites. No se ejecuta Restaurar sistema en el anfitrión. Guarda el archivo como `Actividad_3_18_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |

## A19 · Leer un instalador MSI o EXE

Tiempo orientativo: 20 minutos. Modalidad: individual. Valoración formativa: 10 puntos.

### Antes de responder

Repasa los bloques B8. Identifica qué información aporta el caso y qué datos faltan. Las soluciones no se deducen por repetir un nombre de herramienta: hay que explicar qué comprobaría y con qué resultado.

### Caso de trabajo

Dos descargas se llaman editor.msi y editor-setup.exe. Una persona concluye que el MSI es necesariamente seguro, que siempre creará un punto de restauración y que el EXE nunca puede contener un MSI.

### Cuestiones

1. Revisa las tres afirmaciones y señala qué se puede deducir realmente de la extensión.
2. Propón una lista de datos que comprobarías en origen, editor, arquitectura y licencia antes de ejecutar.
3. Describe qué decisiones revisarías en carpeta, componentes, opciones adicionales y reinicio.
4. Define prueba funcional y ruta de desinstalación sin inventar que todos los instaladores ofrecen idénticas pantallas.

### Entrega de esta actividad

Análisis del caso y lista de aceptación de una aplicación. No hace falta ejecutar archivos descargados. Guarda el archivo como `Actividad_3_19_Apellidos_Nombre.pdf`. Incluye las preguntas numeradas, razonamiento propio y fuentes concretas cuando consultes información adicional. No se pide añadir una portada vacía ni capturas de asistentes que no ejecutas.

### Revisión y valoración

| Criterio | Puntos |
| --- | ---: |
| Conceptos y datos interpretados correctamente | 4 |
| Justificación y relación entre causa y resultado | 3 |
| Tabla, esquema o propuesta solicitada | 2 |
| Claridad, fuentes y entrega | 1 |
