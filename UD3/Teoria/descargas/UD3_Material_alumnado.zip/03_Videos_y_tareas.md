# Unidad 3. Vídeos y tareas de visionado

Sistemas Informáticos · 1.º de DAM · Catálogo vinculado a teoría y laboratorio

## Cómo utilizar el catálogo

Los enlaces siguientes apuntan a vídeos concretos, no a páginas de resultados. Se ha comprobado su presencia y se han consultado sus descripciones o transcripciones disponibles el 26 de octubre de 2026. No se afirma haber reproducido y revisado íntegramente cada vídeo. Antes de proyectarlos, el docente debe comprobar reproducción, sonido, publicidad y adecuación al grupo. Los vídeos antiguos sirven para conceptos; las interfaces y los requisitos se contrastan con la documentación escrita de la unidad.

El alumnado puede utilizar transcripción y texto como alternativa al visionado. Las duraciones solo se indican cuando la fuente las muestra. No se descargan ni se redistribuyen vídeos ajenos; se enlaza al autor o a la mediateca. El catálogo contiene ocho recursos y ocho tareas asociadas.

## V1. Máquinas virtuales con Virtual Box

Autor: Óscar García, publicado en EducaMadrid el 23 de junio de 2026. Idioma: castellano. Enlace: https://mediateca.educa.madrid.org/video/bh97chmwc7d66tfd

Relación: B2 y B6; preparación de P1. Aporta una presentación del laboratorio y su gestión. No copies literalmente todas las simplificaciones del relato: usa las definiciones del cuaderno para explicar recursos y aislamiento.

Antes: escribe qué diferencia esperas entre el ordenador real y una VM. Durante: dibuja anfitrión, hipervisor e invitado; localiza una decisión sobre hardware virtual. Después: explica por qué poder configurar 8 GiB en una VM no demuestra que el anfitrión tenga memoria suficiente para usarla cómodamente.

Tarea de transferencia: compara el esquema del vídeo con la ficha real de P0. Entrega un diagrama y dos decisiones propias. Criterio: identifica capas y relaciona la asignación con recursos físicos, sin considerar la VM una máquina con recursos ilimitados.

## V2. Crear máquina virtual. Virtualbox

Autora: Susana López Luengo, IES Palomeras-Vallecas, EducaMadrid. Publicado el 4 de mayo de 2022. Castellano. Duración publicada: 11 min 10 s. Enlace: https://mediateca.educa.madrid.org/video/zx533nop3jd9ybjs

Relación: B3 y B6; P1. El ejemplo emplea Windows 10 y una interfaz anterior: se aprovechan las decisiones de creación, no sus requisitos como referencia para Windows 11.

Antes: distingue ISO y disco virtual. Durante: anota nombre de VM, ubicación, memoria y formato de disco. Después: señala tres decisiones que has adaptado a Ubuntu y explica por qué.

Tarea: reproduce la creación de una VM vacía y predice el arranque sin ISO antes de probarlo. Entrega ficha de equivalencias «opción del vídeo / opción actual / finalidad». Criterio: identifica funciones aunque cambien nombres y ubicación del menú.

## V3. Instalación Ubuntu desktop 24.04

Autor publicado: Agustín N., EducaMadrid. Publicado el 17 de febrero de 2026. Castellano. Enlace: https://mediateca.educa.madrid.org/video/4dpxwfhdfpr4p799

Relación: B7; P2. La transcripción presenta una instalación de Ubuntu en VirtualBox. Los recursos elegidos por el autor son los de su ejemplo, no sustituyen el presupuesto de P0.

Antes: define qué prueba demostraría instalación persistente. Durante: pausa antes de confirmar el destino; identifica disco afectado y opciones de datos. Después: explica qué debes comprobar tras retirar la ISO.

Tarea: redacta una lista de aceptación de seis puntos y aplícala a tu VM. Adjunta resultados reales, no una transcripción del vídeo. Criterio: reconoce el destino de instalación y comprueba persistencia y arranque autónomo.

## V4. Virtual box. Instantáneas

Autora: Susana López Luengo, IES Palomeras-Vallecas, EducaMadrid. Publicado el 4 de mayo de 2022. Castellano. Duración publicada: 6 min 16 s. Enlace: https://mediateca.educa.madrid.org/video/zgauof85771q51t9

Relación: B11; P7. Atención didáctica: una instantánea puede tomarse apagada o en ejecución según el caso; no es obligatorio mantener encendida la VM. En esta unidad se usa apagada para simplificar la prueba. La analogía de «copia de seguridad» necesita completarse: depende de la estructura de discos y no cubre la pérdida de esa ubicación.

Antes: escribe qué esperas recuperar. Durante: dibuja estados A, B y vuelta a A. Después: identifica qué archivo posterior dejaría de estar en el estado restaurado.

Tarea: realiza P7 y añade un párrafo sobre una avería que la instantánea no cubre. Criterio: predice pérdida de cambios y distingue retorno lógico de protección frente a avería física.

## V5. Ejercicio 6 y 7 Virtualbox Red NAT

Autor: Daniel González Trabada, IES Francisco de Quevedo, EducaMadrid. Publicado el 20 de octubre de 2026. Castellano con subtítulos indicados por la fuente. Duración publicada: 10 min 15 s. Enlace: https://mediateca.educa.madrid.org/video/amomshvzq7iz1llo

Relación: B9; P5. El recurso muestra ajustes y corrección de errores: úsalo también para analizar el diagnóstico. Emplea direcciones y un servicio SSH de su propio ejercicio. En nuestra práctica se utiliza HTTP y se anotan las IP reales.

Antes: explica diferencia entre NAT y Red NAT. Durante: representa quién recibe el tráfico y localiza una corrección de dirección. Después: sustituye el ejemplo por anfitrión 127.0.0.1:8080 → invitado:8000.

Tarea: completa tabla «origen / dirección utilizada / puerto / destino final» para la prueba HTTP. Criterio: entiende el reenvío y no copia una IP del vídeo que no existe en su red. No es necesario instalar SSH para completar P5.

## V6. Virtual box. Clonar máquinas virtuales

Autora: Susana López Luengo, IES Palomeras-Vallecas, EducaMadrid. Publicado el 4 de mayo de 2022. Castellano. Duración publicada: 4 min 44 s. Enlace: https://mediateca.educa.madrid.org/video/52n4vscswgb1rwq3

Relación: B11; P8. El ejemplo usa Windows 10, pero la comparación de clones se traslada al Ubuntu del laboratorio.

Antes: predice qué necesita un clon enlazado para arrancar. Durante: registra independencia, ocupación y MAC. Después: explica por qué generar nueva MAC no resuelve automáticamente una IP fija duplicada ni todas las identidades del sistema.

Tarea: escribe una recomendación para transportar la máquina a otro ordenador y otra para ahorrar espacio en un aula. Criterio: elige clon completo o enlazado según dependencias y destino; no compara solo el tiempo de creación.

## V7. Docker — La explicación que querías

Autor: Ringa Tech. Publicado el 7 de julio de 2022. Castellano. Enlace: https://www.youtube.com/watch?v=9eTVZwMZJsA

Relación: B12; X2. Como introducción puede seleccionarse el tramo inicial de comparación y funcionamiento, aproximadamente hasta el minuto 6. La descripción del autor incluye capítulos; las instrucciones de instalación y las condiciones comerciales se comprueban en documentación actual.

Antes: dibuja una VM Linux con su kernel. Durante: añade la capa de contenedores al esquema. Después: explica dónde está el kernel que utiliza el contenedor de X2.

Tarea: crea una tabla con VM y contenedor: qué arrancan, qué comparten, qué datos desaparecen al eliminar la instancia y qué conviene respaldar. Criterio: distingue imagen, instancia y volumen, y evita presentar un contenedor como un sistema completo con kernel independiente.

## V8. Virtual box. OVAS

Autora: Susana López Luengo, IES Palomeras-Vallecas, EducaMadrid. Publicado el 4 de mayo de 2022. Castellano. Duración publicada: 5 min 36 s. Enlace: https://mediateca.educa.madrid.org/video/igyhx275rxb5rsfu

Relación: B11; P8. Se utiliza para observar exportación e importación. Completa el ejemplo con inventario y prueba posterior: la portabilidad depende del contenido del paquete y de la plataforma de destino.

Antes: indica tres datos que guardarías además del OVA. Durante: identifica origen, paquete y máquina importada. Después: propone cuatro pruebas para aceptar la importación.

Tarea: redacta un protocolo de transferencia de una página y compruébalo con tu OVA. Criterio: incluye arranque y archivo testigo; no da por válido un respaldo solamente porque terminó la barra de progreso.

## Ficha común para cualquier vídeo

Identificación del recurso y fecha. Concepto previo que quiero aclarar. Predicción antes del visionado. Dos ideas explicadas con palabras propias. Una diferencia entre el ejemplo y mi laboratorio. Acción práctica relacionada. Prueba de que la acción funciona. Duda que aún necesito resolver. No se evalúa copiar frases del autor.

## Guiones para vídeos propios del docente

Estos son planes de grabación, no vídeos ya producidos. Permiten cubrir conceptos para los que interesa mostrar exactamente la versión del aula.

### G1. Del firmware al escritorio · 7-9 minutos

Inicio: VM vacía y pregunta «¿qué falta para arrancar?». Desarrollo: mostrar medio, firmware y orden de arranque; instalar o usar una máquina preparada; retirar ISO y arrancar desde disco. Pizarra: firmware → cargador → kernel → servicios → sesión. Cierre: comparar escritorio Live con persistencia. Pregunta de pausa: ¿qué cambia si dejo conectada la ISO? Vinculación: B3-B4 y P1-P2.

### G2. Particionar sin confundir el destino · 10-12 minutos

Inicio: lsblk con disco de sistema y VDI de 8 GiB. Desarrollo: identificar tamaño, montajes, GPT, partición ext4 y espacio restante; mostrar comprobación antes de formatear. Cierre: montar y comparar lsblk con df. Pausa antes de confirmar para que el alumnado indique qué disco quedará afectado. Vinculación: B4-B5 y P4.

### G3. Windows 11 con aceptación completa · 10-15 minutos

Inicio: ficha del hardware virtual y condiciones de uso de aula, sin mostrar claves. Desarrollo: destino, instalación y cuenta prevista; corte durante esperas. Cierre: winver, msinfo32, TPM, discos, dispositivos y actualizaciones. Pausa: ¿qué impide dar el equipo por terminado? Vinculación: B8 y P3. Utiliza la edición real del centro y verifica sus pantallas antes de grabar.

### G4. Una petición web atraviesa la red virtual · 8-10 minutos

Inicio: servidor de Python en Ubuntu. Desarrollo: bucle local del invitado, IP solo anfitrión y reenvío desde el anfitrión. Dibujar las tres rutas con puertos. Provocar fallo deteniendo únicamente el proceso. Cierre: diagnóstico servicio frente a dirección de red. Vinculación: B9 y P5.

### G5. Recuperar con una predicción · 6-8 minutos

Inicio: estados A y B en papel. Desarrollo: instantánea apagada, archivo posterior y restauración. Cierre: copiar la carpeta externa de evidencias y explicar por qué una instantánea no protege frente a pérdida del SSD. Vinculación: B11 y P7.
